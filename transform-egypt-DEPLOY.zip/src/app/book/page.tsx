'use client';

import { useState } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { motion, AnimatePresence } from 'framer-motion';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { CheckCircle, Clock, Phone, ArrowRight, ArrowLeft, Calendar, User } from 'lucide-react';
import { I18nProvider, useI18n } from '@/hooks/useI18n';
import { Navigation } from '@/components/layout/Navigation';
import { Footer } from '@/components/layout/Footer';
import { WhatsAppButton } from '@/components/layout/WhatsAppButton';
import { SERVICES, WHATSAPP_NUMBER } from '@/lib/data';
import { cn } from '@/lib/utils';

const bookingSchema = z.object({
  firstName: z.string().min(2, 'First name required'),
  lastName: z.string().min(2, 'Last name required'),
  email: z.string().email('Valid email required'),
  phone: z.string().min(10, 'Valid phone required'),
  specialRequests: z.string().optional(),
});

type BookingForm = z.infer<typeof bookingSchema>;

const TIME_SLOTS = [
  '10:00 AM', '10:30 AM', '11:00 AM', '11:30 AM',
  '12:00 PM', '12:30 PM', '1:00 PM', '1:30 PM',
  '2:00 PM', '2:30 PM', '3:00 PM', '3:30 PM',
  '4:00 PM', '4:30 PM', '5:00 PM', '5:30 PM',
  '6:00 PM', '6:30 PM', '7:00 PM', '7:30 PM',
];

// Generate next 30 days
function getAvailableDates(): string[] {
  const dates: string[] = [];
  const today = new Date();
  for (let i = 1; i <= 30; i++) {
    const d = new Date(today);
    d.setDate(today.getDate() + i);
    dates.push(d.toISOString().split('T')[0]);
  }
  return dates;
}

function BookingContent() {
  const { t, locale } = useI18n();
  const [step, setStep] = useState(1);
  const [selectedService, setSelectedService] = useState('');
  const [selectedVariant, setSelectedVariant] = useState('');
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedTime, setSelectedTime] = useState('');
  const [confirmed, setConfirmed] = useState(false);
  const [bookingRef] = useState(`TF-${Date.now().toString().slice(-6)}`);

  const availableDates = getAvailableDates();
  const currentService = SERVICES.find(s => s.id === selectedService);
  const currentVariant = currentService?.variants.find(v => v.id === selectedVariant);

  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<BookingForm>({
    resolver: zodResolver(bookingSchema),
  });

  const onSubmit = async (data: BookingForm) => {
    await new Promise(r => setTimeout(r, 1200)); // simulate API
    setConfirmed(true);
  };

  const STEPS = [
    t('booking.step1'),
    t('booking.step2'),
    t('booking.step3') + ' & ' + t('booking.step4'),
    t('booking.step5'),
  ];

  if (confirmed) {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="min-h-[60vh] flex items-center justify-center py-20"
      >
        <div className="max-w-lg w-full text-center px-4">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: 'spring', delay: 0.2 }}
            className="w-20 h-20 rounded-full bg-gold flex items-center justify-center mx-auto mb-8"
          >
            <CheckCircle className="w-10 h-10 text-black" />
          </motion.div>
          <h1 className="font-serif text-3xl text-white mb-3">{t('booking.confirmationTitle')}</h1>
          <p className="text-warm-grey mb-2">{t('booking.confirmationDesc')}</p>
          <p className="text-gold font-semibold text-lg mb-8">#{bookingRef}</p>

          <div className="bg-charcoal border border-white/8 p-6 text-start mb-8 space-y-3">
            {currentService && (
              <div className="flex justify-between text-sm">
                <span className="text-warm-grey">{locale === 'ar' ? 'الخدمة' : 'Service'}</span>
                <span className="text-white font-medium">{locale === 'ar' ? currentService.name.ar : currentService.name.en}</span>
              </div>
            )}
            {selectedDate && (
              <div className="flex justify-between text-sm">
                <span className="text-warm-grey">{locale === 'ar' ? 'التاريخ' : 'Date'}</span>
                <span className="text-white font-medium">{selectedDate}</span>
              </div>
            )}
            {selectedTime && (
              <div className="flex justify-between text-sm">
                <span className="text-warm-grey">{locale === 'ar' ? 'الوقت' : 'Time'}</span>
                <span className="text-white font-medium">{selectedTime}</span>
              </div>
            )}
          </div>

          <div className="flex flex-col gap-3">
            <Link href="/" className="btn btn-shop w-full justify-center">
              {locale === 'ar' ? 'العودة للرئيسية' : 'Back to Home'}
            </Link>
            <a
              href={`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(`Hi! My booking reference is #${bookingRef}`)}`}
              target="_blank"
              rel="noopener noreferrer"
              className="btn btn-ghost w-full justify-center"
            >
              {locale === 'ar' ? 'تواصل عبر واتساب' : 'Contact via WhatsApp'}
            </a>
          </div>
        </div>
      </motion.div>
    );
  }

  return (
    <div className="py-20 px-4">
      <div className="max-w-3xl mx-auto">

        {/* Header */}
        <div className="text-center mb-12">
          <span className="section-eyebrow">{t('booking.title')}</span>
          <div className="gold-divider-center" />
          <h1 className="font-serif text-white text-4xl mb-4">{t('booking.title')}</h1>
          <p className="text-warm-grey">{t('booking.subtitle')}</p>
        </div>

        {/* Step Progress */}
        <div className="flex items-center justify-center gap-2 mb-10">
          {STEPS.map((label, i) => (
            <div key={i} className="flex items-center gap-2">
              <div className={cn(
                'w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-all duration-300',
                step > i + 1 ? 'bg-gold text-black' :
                step === i + 1 ? 'bg-gold text-black' :
                'bg-white/10 text-warm-grey'
              )}>
                {step > i + 1 ? '✓' : i + 1}
              </div>
              <span className={cn(
                'text-xs hidden md:block transition-colors',
                step === i + 1 ? 'text-gold' : 'text-warm-grey'
              )}>{label}</span>
              {i < STEPS.length - 1 && (
                <div className={cn('h-[1px] w-8 md:w-12 transition-colors', step > i + 1 ? 'bg-gold' : 'bg-white/10')} />
              )}
            </div>
          ))}
        </div>

        {/* Step Content */}
        <AnimatePresence mode="wait">

          {/* Step 1: Select Service */}
          {step === 1 && (
            <motion.div key="step1" initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -30 }}>
              <h2 className="font-serif text-white text-2xl mb-6">{t('booking.step1')}</h2>
              <div className="space-y-4">
                {SERVICES.map(service => (
                  <div key={service.id}>
                    <button
                      onClick={() => {
                        setSelectedService(service.id);
                        setSelectedVariant('');
                      }}
                      className={cn(
                        'w-full text-start p-5 border transition-all duration-200',
                        selectedService === service.id
                          ? 'border-gold bg-gold/5'
                          : 'border-white/10 bg-charcoal hover:border-white/25'
                      )}
                    >
                      <div className="flex justify-between items-center">
                        <div>
                          <p className="font-semibold text-white">
                            {locale === 'ar' ? service.name.ar : service.name.en}
                          </p>
                          <p className="text-warm-grey text-sm mt-1">
                            {locale === 'ar' ? service.shortDescription.ar : service.shortDescription.en}
                          </p>
                        </div>
                        <span className="text-gold font-serif ml-4 flex-shrink-0">
                          EGP {service.startingPrice.toLocaleString()}+
                        </span>
                      </div>
                    </button>

                    {/* Variants */}
                    {selectedService === service.id && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-2 pl-4"
                      >
                        {service.variants.map(v => (
                          <button
                            key={v.id}
                            onClick={() => setSelectedVariant(v.id)}
                            className={cn(
                              'text-start p-3 border text-sm transition-all',
                              selectedVariant === v.id
                                ? 'border-gold bg-gold/8 text-white'
                                : 'border-white/8 text-warm-grey hover:border-white/20'
                            )}
                          >
                            <span className="block font-medium">{locale === 'ar' ? v.name.ar : v.name.en}</span>
                            <span className="text-xs text-warm-grey flex items-center gap-2 mt-0.5">
                              <Clock className="w-3 h-3" /> {v.duration} min · EGP {v.price.toLocaleString()}
                            </span>
                          </button>
                        ))}
                      </motion.div>
                    )}
                  </div>
                ))}
              </div>

              <div className="flex justify-end mt-8">
                <button
                  onClick={() => setStep(2)}
                  disabled={!selectedService || !selectedVariant}
                  className="btn btn-shop inline-flex gap-2 disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  {t('misc.seeAll') === 'See All' ? 'Continue' : 'التالي'}
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </motion.div>
          )}

          {/* Step 2: Date & Time */}
          {step === 2 && (
            <motion.div key="step2" initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -30 }}>
              <h2 className="font-serif text-white text-2xl mb-6">{t('booking.step2')}</h2>

              {/* Date Picker */}
              <div className="mb-8">
                <label className="text-warm-grey text-sm uppercase tracking-wider mb-3 block">
                  {t('booking.selectDate')}
                </label>
                <div className="grid grid-cols-4 sm:grid-cols-6 md:grid-cols-7 gap-2">
                  {availableDates.slice(0, 21).map(date => {
                    const d = new Date(date);
                    const dayName = d.toLocaleDateString('en', { weekday: 'short' });
                    const dayNum = d.getDate();
                    const month = d.toLocaleDateString('en', { month: 'short' });
                    return (
                      <button
                        key={date}
                        onClick={() => setSelectedDate(date)}
                        className={cn(
                          'flex flex-col items-center py-3 px-2 border text-xs transition-all',
                          selectedDate === date
                            ? 'border-gold bg-gold text-black font-bold'
                            : 'border-white/10 text-warm-grey hover:border-white/30 hover:text-white'
                        )}
                      >
                        <span className="font-medium">{dayName}</span>
                        <span className="text-lg font-bold mt-0.5">{dayNum}</span>
                        <span>{month}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Time Slots */}
              {selectedDate && (
                <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
                  <label className="text-warm-grey text-sm uppercase tracking-wider mb-3 block">
                    {t('booking.selectTime')}
                  </label>
                  <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-2">
                    {TIME_SLOTS.map(time => {
                      // Randomly mark some as unavailable for demo
                      const unavailable = ['11:00 AM', '1:00 PM', '4:30 PM'].includes(time);
                      return (
                        <button
                          key={time}
                          onClick={() => !unavailable && setSelectedTime(time)}
                          disabled={unavailable}
                          className={cn(
                            'py-2.5 text-xs border transition-all',
                            unavailable ? 'border-white/5 text-white/20 cursor-not-allowed line-through' :
                            selectedTime === time ? 'border-gold bg-gold text-black font-bold' :
                            'border-white/10 text-warm-grey hover:border-white/30 hover:text-white'
                          )}
                        >
                          {time}
                        </button>
                      );
                    })}
                  </div>
                </motion.div>
              )}

              <div className="flex justify-between mt-8">
                <button onClick={() => setStep(1)} className="btn btn-ghost inline-flex gap-2">
                  <ArrowLeft className="w-4 h-4" /> {t('quiz.back')}
                </button>
                <button
                  onClick={() => setStep(3)}
                  disabled={!selectedDate || !selectedTime}
                  className="btn btn-shop inline-flex gap-2 disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  {t('quiz.next')} <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </motion.div>
          )}

          {/* Step 3: Personal Details */}
          {step === 3 && (
            <motion.div key="step3" initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -30 }}>
              <h2 className="font-serif text-white text-2xl mb-6">{t('booking.step4')}</h2>

              <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <div>
                    <label className="text-warm-grey text-xs uppercase tracking-wider mb-2 block">
                      {t('booking.firstName')} *
                    </label>
                    <input
                      {...register('firstName')}
                      className="input-luxury-box"
                      placeholder={locale === 'ar' ? 'اسمك' : 'Your first name'}
                    />
                    {errors.firstName && <p className="text-red-400 text-xs mt-1">{errors.firstName.message}</p>}
                  </div>
                  <div>
                    <label className="text-warm-grey text-xs uppercase tracking-wider mb-2 block">
                      {t('booking.lastName')} *
                    </label>
                    <input
                      {...register('lastName')}
                      className="input-luxury-box"
                      placeholder={locale === 'ar' ? 'اسم العائلة' : 'Your last name'}
                    />
                    {errors.lastName && <p className="text-red-400 text-xs mt-1">{errors.lastName.message}</p>}
                  </div>
                </div>

                <div>
                  <label className="text-warm-grey text-xs uppercase tracking-wider mb-2 block">
                    {t('booking.email')} *
                  </label>
                  <input
                    {...register('email')}
                    type="email"
                    className="input-luxury-box"
                    placeholder="your@email.com"
                  />
                  {errors.email && <p className="text-red-400 text-xs mt-1">{errors.email.message}</p>}
                </div>

                <div>
                  <label className="text-warm-grey text-xs uppercase tracking-wider mb-2 block">
                    {t('booking.phone')} *
                  </label>
                  <input
                    {...register('phone')}
                    type="tel"
                    className="input-luxury-box"
                    placeholder="01XXXXXXXXX"
                  />
                  {errors.phone && <p className="text-red-400 text-xs mt-1">{errors.phone.message}</p>}
                </div>

                <div>
                  <label className="text-warm-grey text-xs uppercase tracking-wider mb-2 block">
                    {t('booking.specialRequests')}
                  </label>
                  <textarea
                    {...register('specialRequests')}
                    rows={3}
                    className="input-luxury-box resize-none"
                    placeholder={locale === 'ar' ? 'أي طلبات خاصة...' : 'Any special requests or notes...'}
                  />
                </div>

                {/* Booking Summary */}
                <div className="bg-charcoal border border-gold/20 p-5 space-y-2">
                  <p className="text-gold text-xs uppercase tracking-wider mb-3">{t('booking.step5')}</p>
                  {currentService && (
                    <div className="flex justify-between text-sm">
                      <span className="text-warm-grey">{locale === 'ar' ? 'الخدمة' : 'Service'}</span>
                      <span className="text-white">{locale === 'ar' ? currentService.name.ar : currentService.name.en}</span>
                    </div>
                  )}
                  {currentVariant && (
                    <div className="flex justify-between text-sm">
                      <span className="text-warm-grey">{locale === 'ar' ? 'النوع' : 'Type'}</span>
                      <span className="text-white">{locale === 'ar' ? currentVariant.name.ar : currentVariant.name.en}</span>
                    </div>
                  )}
                  {selectedDate && (
                    <div className="flex justify-between text-sm">
                      <span className="text-warm-grey">{locale === 'ar' ? 'التاريخ' : 'Date'}</span>
                      <span className="text-white">{selectedDate} at {selectedTime}</span>
                    </div>
                  )}
                  {currentVariant && (
                    <div className="flex justify-between text-sm border-t border-white/8 pt-2 mt-2">
                      <span className="text-white font-semibold">{locale === 'ar' ? 'السعر' : 'Price'}</span>
                      <span className="text-gold font-serif font-semibold">EGP {currentVariant.price.toLocaleString()}</span>
                    </div>
                  )}
                </div>

                <div className="flex justify-between">
                  <button type="button" onClick={() => setStep(2)} className="btn btn-ghost inline-flex gap-2">
                    <ArrowLeft className="w-4 h-4" /> {t('quiz.back')}
                  </button>
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="btn btn-shop inline-flex gap-2 min-w-[180px] justify-center"
                  >
                    {isSubmitting ? (
                      <span className="flex items-center gap-2">
                        <span className="w-4 h-4 border-2 border-black/30 border-t-black rounded-full animate-spin" />
                        {locale === 'ar' ? 'جاري...' : 'Processing...'}
                      </span>
                    ) : (
                      <>{t('booking.confirmBooking')} <CheckCircle className="w-4 h-4" /></>
                    )}
                  </button>
                </div>
              </form>

              {/* WhatsApp alternative */}
              <p className="text-center text-warm-grey text-sm mt-6">
                {locale === 'ar' ? 'تفضلي الحجز عبر واتساب؟' : 'Prefer to book via WhatsApp?'}{' '}
                <a
                  href={`https://wa.me/${WHATSAPP_NUMBER}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gold hover:underline"
                >
                  {t('booking.whatsappBooking')}
                </a>
              </p>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

export default function BookPage() {
  return (
    <I18nProvider>
      <Navigation />
      <main id="main-content" className="bg-black min-h-screen pt-20">
        <BookingContent />
      </main>
      <Footer />
      <WhatsAppButton />
    </I18nProvider>
  );
}
