import { MetadataRoute } from 'next';

export default function sitemap(): MetadataRoute.Sitemap {
  const baseUrl = 'https://transform-egypt.com';
  const lastModified = new Date();

  const routes = [
    '', '/services', '/boutique', '/book', '/transformations',
    '/reviews', '/about', '/contact', '/blog', '/cart',
    '/hair-extensions-egypt', '/hair-extensions-cairo',
    '/lash-extensions-cairo', '/microblading-cairo',
  ];

  return routes.map(route => ({
    url: `${baseUrl}${route}`,
    lastModified,
    changeFrequency: route === '' ? 'daily' : 'weekly',
    priority: route === '' ? 1 : route.startsWith('/hair') ? 0.9 : 0.8,
  }));
}
