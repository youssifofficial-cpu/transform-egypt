import type { Metadata, Viewport } from 'next';
import { Playfair_Display, Inter, Cairo } from 'next/font/google';
import './globals.css';

const playfair = Playfair_Display({
  subsets: ['latin'],
  weight: ['400', '500', '600', '700'],
  style: ['normal', 'italic'],
  variable: '--font-playfair',
  display: 'swap',
  preload: true,
});

const inter = Inter({
  subsets: ['latin'],
  weight: ['300', '400', '500', '600', '700'],
  variable: '--font-inter',
  display: 'swap',
  preload: true,
});

const cairo = Cairo({
  subsets: ['arabic', 'latin'],
  weight: ['300', '400', '500', '600', '700'],
  variable: '--font-cairo',
  display: 'swap',
  preload: false,
});

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  maximumScale: 5,
  themeColor: '#000000',
};

export const metadata: Metadata = {
  metadataBase: new URL('https://transform-egypt.com'),
  title: {
    default: 'TransforM Egypt — #1 Hair Extensions & Luxury Beauty in Cairo',
    template: '%s | TransforM Egypt',
  },
  description: "Egypt's #1 luxury beauty salon. Premium hair extensions, lash extensions, microblading, facials & professional makeup in Cairo. Celebrity-level results for every client.",
  keywords: ['hair extensions Egypt', 'hair extensions Cairo', 'luxury beauty salon Cairo', 'microblading Cairo', 'lash extensions Egypt', 'TransforM Egypt', 'وصلات شعر', 'صالون تجميل فاخر'],
  authors: [{ name: 'TransforM Egypt' }],
  creator: 'TransforM Egypt',
  publisher: 'TransforM Egypt',
  robots: {
    index: true,
    follow: true,
    googleBot: { index: true, follow: true, 'max-video-preview': -1, 'max-image-preview': 'large', 'max-snippet': -1 },
  },
  openGraph: {
    type: 'website',
    locale: 'en_US',
    alternateLocale: 'ar_EG',
    url: 'https://transform-egypt.com',
    siteName: 'TransforM Egypt',
    title: 'TransforM Egypt — #1 Hair Extensions & Luxury Beauty in Cairo',
    description: "Egypt's #1 luxury beauty salon. Premium hair extensions, lash extensions, microblading & more.",
    images: [{ url: '/images/og-image.jpg', width: 1200, height: 630, alt: 'TransforM Egypt - Luxury Beauty Salon' }],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'TransforM Egypt — #1 Hair Extensions & Luxury Beauty',
    description: "Egypt's #1 luxury beauty salon. Hair extensions, lashes, microblading & more.",
    images: ['/images/og-image.jpg'],
  },
  alternates: {
    canonical: 'https://transform-egypt.com',
    languages: {
      'en': 'https://transform-egypt.com/en',
      'ar': 'https://transform-egypt.com/ar',
    },
  },
  icons: {
    icon: [
      { url: '/favicon.ico', sizes: '32x32' },
      { url: '/icon.svg', type: 'image/svg+xml' },
    ],
    apple: [{ url: '/apple-touch-icon.png', sizes: '180x180' }],
  },
  manifest: '/manifest.json',
  verification: {
    google: 'your-google-verification-code',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" dir="ltr" className={`${playfair.variable} ${inter.variable} ${cairo.variable}`}>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="dns-prefetch" href="https://www.google-analytics.com" />
      </head>
      <body className="bg-black text-white antialiased">
        <a href="#main-content" className="skip-link">Skip to main content</a>
        {children}
      </body>
    </html>
  );
}
