'use client';

import Link from 'next/link';
import { motion } from 'framer-motion';
import { I18nProvider, useI18n } from '@/hooks/useI18n';
import { Navigation } from '@/components/layout/Navigation';
import { Footer } from '@/components/layout/Footer';

function NotFoundContent() {
  const { locale } = useI18n();
  return (
    <div className="min-h-screen bg-black flex items-center justify-center pt-20 px-4">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center max-w-md"
      >
        <p className="font-serif text-gold text-8xl mb-6">404</p>
        <h1 className="font-serif text-white text-3xl mb-4">
          {locale === 'ar' ? 'الصفحة غير موجودة' : 'Page Not Found'}
        </h1>
        <p className="text-warm-grey mb-8">
          {locale === 'ar'
            ? 'الصفحة التي تبحثين عنها غير موجودة أو تم نقلها.'
            : 'The page you're looking for doesn't exist or has been moved.'}
        </p>
        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <Link href="/" className="btn btn-shop">
            {locale === 'ar' ? 'العودة للرئيسية' : 'Back to Home'}
          </Link>
          <Link href="/book" className="btn btn-secondary">
            {locale === 'ar' ? 'احجز موعداً' : 'Book Appointment'}
          </Link>
        </div>
      </motion.div>
    </div>
  );
}

export default function NotFound() {
  return (
    <I18nProvider>
      <Navigation />
      <main id="main-content"><NotFoundContent /></main>
      <Footer />
    </I18nProvider>
  );
}
