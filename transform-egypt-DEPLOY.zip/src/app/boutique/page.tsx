'use client';

import { useState, useMemo } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { ShoppingBag, Heart, Eye, Star, SlidersHorizontal, ChevronDown } from 'lucide-react';
import { I18nProvider, useI18n } from '@/hooks/useI18n';
import { Navigation } from '@/components/layout/Navigation';
import { Footer } from '@/components/layout/Footer';
import { WhatsAppButton } from '@/components/layout/WhatsAppButton';
import { useCartStore } from '@/store/cart';
import { PRODUCTS } from '@/lib/data';
import { cn } from '@/lib/utils';

const CATEGORIES = [
  { id: 'all', en: 'All Products', ar: 'كل المنتجات' },
  { id: 'hair-extensions', en: 'Hair Extensions', ar: 'وصلات الشعر' },
  { id: 'wigs', en: 'Wigs', ar: 'باروكات' },
  { id: 'hair-care', en: 'Hair Care', ar: 'عناية بالشعر' },
];

const SORT_OPTIONS = [
  { id: 'featured', en: 'Featured', ar: 'مميز' },
  { id: 'price-asc', en: 'Price: Low to High', ar: 'السعر: من الأقل' },
  { id: 'price-desc', en: 'Price: High to Low', ar: 'السعر: من الأعلى' },
  { id: 'rating', en: 'Highest Rated', ar: 'الأعلى تقييماً' },
];

function ProductCard({ product, index }: { product: typeof PRODUCTS[0]; index: number }) {
  const { t, locale } = useI18n();
  const { addItem } = useCartStore();
  const [wishlisted, setWishlisted] = useState(false);
  const [addedToCart, setAddedToCart] = useState(false);

  const handleAddToCart = () => {
    addItem(product);
    setAddedToCart(true);
    setTimeout(() => setAddedToCart(false), 2000);
  };

  const badgeLabel = product.badge === 'bestseller' ? (locale === 'ar' ? 'الأكثر مبيعاً' : 'BESTSELLER')
    : product.badge === 'new' ? (locale === 'ar' ? 'جديد' : 'NEW')
    : product.badge === 'sale' ? (locale === 'ar' ? 'تخفيض' : 'SALE')
    : product.badge === 'limited' ? (locale === 'ar' ? 'محدود' : 'LIMITED')
    : null;

  const discount = product.originalPrice
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
    : 0;

  return (
    <motion.article
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6, delay: index * 0.08 }}
      className="card-product group relative bg-white"
    >
      {/* Image */}
      <div className="relative aspect-[4/3] overflow-hidden bg-ivory">
        <Image
          src={product.images[0] || '/images/products/placeholder.jpg'}
          alt={locale === 'ar' ? product.name.ar : product.name.en}
          fill
          className="object-cover transition-transform duration-700 ease-luxury group-hover:scale-105"
          sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 25vw"
        />

        {/* Badge */}
        {badgeLabel && (
          <div className={cn('absolute top-3 left-3 badge-gold z-10',
            product.badge === 'sale' && 'bg-red-500 text-white border-0'
          )}>
            {badgeLabel}
          </div>
        )}

        {/* Discount % */}
        {discount > 0 && (
          <div className="absolute top-3 right-3 w-10 h-10 rounded-full bg-red-500 flex items-center justify-center z-10">
            <span className="text-white text-[10px] font-bold">-{discount}%</span>
          </div>
        )}

        {/* Hover Actions */}
        <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center gap-2 z-20">
          <button
            onClick={handleAddToCart}
            className={cn(
              'px-4 py-2 text-xs font-bold uppercase tracking-wider transition-all',
              addedToCart ? 'bg-green-500 text-white' : 'bg-gold text-black hover:bg-white'
            )}
            aria-label={addedToCart ? 'Added!' : t('boutique.addToCart')}
          >
            {addedToCart ? '✓ ' + (locale === 'ar' ? 'تمت الإضافة' : 'Added!') : t('boutique.addToCart')}
          </button>
        </div>

        {/* Wishlist */}
        <button
          onClick={() => setWishlisted(!wishlisted)}
          className="absolute top-3 right-3 w-8 h-8 bg-white/90 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all z-30"
          aria-label={t('boutique.wishlist')}
          style={{ top: discount > 0 ? '3.5rem' : undefined }}
        >
          <Heart className={cn('w-4 h-4 transition-colors', wishlisted ? 'fill-red-500 text-red-500' : 'text-gray-400')} />
        </button>
      </div>

      {/* Details */}
      <div className="p-5">
        {/* Stock status */}
        {product.stockCount !== undefined && product.stockCount <= 5 && product.inStock && (
          <p className="text-orange-500 text-xs mb-2 font-medium">
            {t('boutique.lowStock')} {product.stockCount} {t('boutique.lowStockSuffix')}
          </p>
        )}
        {!product.inStock && (
          <p className="text-red-400 text-xs mb-2 font-medium">{t('boutique.outOfStock')}</p>
        )}

        <h3 className="font-serif text-black text-base mb-1 group-hover:text-gold-dark transition-colors line-clamp-2">
          {locale === 'ar' ? product.name.ar : product.name.en}
        </h3>

        {/* Rating */}
        <div className="flex items-center gap-1.5 mb-3">
          <div className="flex gap-0.5">
            {[...Array(5)].map((_, i) => (
              <Star key={i} className={cn('w-3 h-3', i < Math.floor(product.rating) ? 'fill-gold text-gold' : 'text-taupe fill-taupe')} />
            ))}
          </div>
          <span className="text-warm-grey text-xs">({product.reviewCount})</span>
        </div>

        {/* Price */}
        <div className="flex items-center gap-2">
          <span className="font-serif text-gold font-semibold text-lg">
            EGP {product.price.toLocaleString()}
          </span>
          {product.originalPrice && (
            <span className="text-warm-grey text-sm line-through">
              EGP {product.originalPrice.toLocaleString()}
            </span>
          )}
        </div>
      </div>

      {/* Mobile Add to Cart */}
      <div className="px-5 pb-5">
        <button
          onClick={handleAddToCart}
          disabled={!product.inStock}
          className={cn(
            'w-full btn btn-shop btn-sm',
            !product.inStock && 'opacity-40 cursor-not-allowed',
            addedToCart && 'bg-green-600 border-green-600 text-white'
          )}
        >
          {addedToCart ? (locale === 'ar' ? 'تمت الإضافة ✓' : 'Added ✓') : (
            <>
              <ShoppingBag className="w-3.5 h-3.5" />
              {product.inStock ? t('boutique.addToCart') : t('boutique.outOfStock')}
            </>
          )}
        </button>
      </div>
    </motion.article>
  );
}

function BoutiqueContent() {
  const { t, locale } = useI18n();
  const [activeCategory, setActiveCategory] = useState('all');
  const [sortBy, setSortBy] = useState('featured');
  const [showFilters, setShowFilters] = useState(false);

  const filteredProducts = useMemo(() => {
    let products = [...PRODUCTS];
    if (activeCategory !== 'all') {
      products = products.filter(p => p.category === activeCategory);
    }
    switch (sortBy) {
      case 'price-asc': return products.sort((a, b) => a.price - b.price);
      case 'price-desc': return products.sort((a, b) => b.price - a.price);
      case 'rating': return products.sort((a, b) => b.rating - a.rating);
      default: return products;
    }
  }, [activeCategory, sortBy]);

  return (
    <div className="bg-white min-h-screen">

      {/* Hero Banner */}
      <div className="bg-black py-20 px-4 text-center border-b border-white/8">
        <span className="section-eyebrow">{t('boutique.title')}</span>
        <div className="gold-divider-center" />
        <h1 className="font-serif text-white text-4xl md:text-5xl mb-4">{t('boutique.title')}</h1>
        <p className="text-warm-grey max-w-xl mx-auto">{t('boutique.subtitle')}</p>
      </div>

      {/* Filters Bar */}
      <div className="sticky top-[72px] z-30 bg-white border-b border-taupe/60 shadow-sm">
        <div className="container-luxury py-4">
          <div className="flex items-center justify-between gap-4 flex-wrap">

            {/* Category Tabs */}
            <div className="flex items-center gap-1 overflow-x-auto no-scrollbar">
              {CATEGORIES.map(cat => (
                <button
                  key={cat.id}
                  onClick={() => setActiveCategory(cat.id)}
                  className={cn(
                    'px-4 py-2 text-xs uppercase tracking-wider font-medium whitespace-nowrap transition-all',
                    activeCategory === cat.id
                      ? 'bg-black text-white'
                      : 'text-warm-grey hover:text-black'
                  )}
                >
                  {locale === 'ar' ? cat.ar : cat.en}
                </button>
              ))}
            </div>

            {/* Sort */}
            <div className="flex items-center gap-2">
              <span className="text-warm-grey text-xs">{t('boutique.sort')}:</span>
              <div className="relative">
                <select
                  value={sortBy}
                  onChange={e => setSortBy(e.target.value)}
                  className="bg-transparent border border-taupe text-black text-xs py-1.5 pl-3 pr-8 appearance-none cursor-pointer focus:outline-none focus:border-gold"
                >
                  {SORT_OPTIONS.map(opt => (
                    <option key={opt.id} value={opt.id}>
                      {locale === 'ar' ? opt.ar : opt.en}
                    </option>
                  ))}
                </select>
                <ChevronDown className="absolute right-2 top-1/2 -translate-y-1/2 w-3 h-3 text-warm-grey pointer-events-none" />
              </div>

              {/* Results count */}
              <span className="text-warm-grey text-xs hidden sm:block">
                {filteredProducts.length} {locale === 'ar' ? 'منتج' : 'products'}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Products Grid */}
      <div className="container-luxury py-12">
        {filteredProducts.length === 0 ? (
          <div className="text-center py-20">
            <p className="text-warm-grey text-lg">{t('misc.noResults')}</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredProducts.map((product, i) => (
              <ProductCard key={product.id} product={product} index={i} />
            ))}
          </div>
        )}

        {/* Empty state CTA */}
        {filteredProducts.length > 0 && (
          <div className="text-center mt-16 py-12 border-t border-taupe/40">
            <p className="text-warm-grey mb-4">
              {locale === 'ar' ? 'لا تجدين ما تبحثين عنه؟' : "Can't find what you're looking for?"}
            </p>
            <a
              href="https://wa.me/201009780008"
              target="_blank"
              rel="noopener noreferrer"
              className="btn btn-primary inline-flex gap-2"
            >
              {locale === 'ar' ? 'تواصلي معنا عبر واتساب' : 'Contact us via WhatsApp'}
            </a>
          </div>
        )}
      </div>
    </div>
  );
}

export default function BoutiquePage() {
  return (
    <I18nProvider>
      <Navigation />
      <main id="main-content" className="pt-20">
        <BoutiqueContent />
      </main>
      <Footer />
      <WhatsAppButton />
    </I18nProvider>
  );
}
