'use client';

import { I18nProvider } from '@/hooks/useI18n';
import { Navigation } from '@/components/layout/Navigation';
import { Footer } from '@/components/layout/Footer';
import { WhatsAppButton } from '@/components/layout/WhatsAppButton';
import { HeroSection } from '@/components/sections/HeroSection';
import { SocialProofSection } from '@/components/sections/SocialProofSection';
import { TransformationsSection } from '@/components/sections/TransformationsSection';
import { ServicesSection } from '@/components/sections/ServicesSection';
import { WhyChooseSection } from '@/components/sections/WhyChooseSection';
import { FounderSection } from '@/components/sections/FounderSection';
import { BranchesSection } from '@/components/sections/BranchesSection';
import { InstagramSection } from '@/components/sections/InstagramSection';
import { QuizSection } from '@/components/sections/QuizSection';
import { TestimonialsSection } from '@/components/sections/TestimonialsSection';
import { CTASection } from '@/components/sections/CTASection';

export default function HomePage() {
  return (
    <I18nProvider>
      <Navigation />
      <main id="main-content">
        <HeroSection />
        <SocialProofSection />
        <TransformationsSection />
        <ServicesSection />
        <WhyChooseSection />
        <FounderSection />
        <BranchesSection />
        <InstagramSection />
        <QuizSection />
        <TestimonialsSection />
        <CTASection />
      </main>
      <Footer />
      <WhatsAppButton />
    </I18nProvider>
  );
}
