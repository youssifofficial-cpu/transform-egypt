'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { Star, ThumbsUp, CheckCircle, Filter } from 'lucide-react';
import { I18nProvider, useI18n } from '@/hooks/useI18n';
import { Navigation } from '@/components/layout/Navigation';
import { Footer } from '@/components/layout/Footer';
import { WhatsAppButton } from '@/components/layout/WhatsAppButton';
import { TESTIMONIALS } from '@/lib/data';
import { cn } from '@/lib/utils';

const OVERALL_RATING = 4.9;
const TOTAL_REVIEWS = 523;
const RATING_BREAKDOWN = [
  { stars: 5, pct: 91 },
  { stars: 4, pct: 6 },
  { stars: 3, pct: 2 },
  { stars: 2, pct: 0.5 },
  { stars: 1, pct: 0.5 },
];

function ReviewCard({ review, index }: { review: typeof TESTIMONIALS[0]; index: number }) {
  const { locale } = useI18n();
  const [helpful, setHelpful] = useState(Math.floor(Math.random() * 30) + 5);
  const [voted, setVoted] = useState(false);

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6, delay: index * 0.08 }}
      className="bg-charcoal border border-white/8 p-7"
    >
      {/* Header */}
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-3">
          {/* Avatar */}
          <div className="w-11 h-11 rounded-full bg-gold/20 flex items-center justify-center font-serif text-gold text-lg font-semibold flex-shrink-0">
            {(locale === 'ar' ? review.clientName.ar : review.clientName.en).charAt(0)}
          </div>
          <div>
            <p className="text-white font-semibold text-sm">
              {locale === 'ar' ? review.clientName.ar : review.clientName.en}
            </p>
            <p className="text-warm-grey text-xs">
              {locale === 'ar' ? review.service.ar : review.service.en}
            </p>
          </div>
        </div>

        {review.verified && (
          <span className="flex items-center gap-1 text-[10px] text-green-400 uppercase tracking-wider">
            <CheckCircle className="w-3 h-3" />
            {locale === 'ar' ? 'موثق' : 'Verified'}
          </span>
        )}
      </div>

      {/* Stars + Date */}
      <div className="flex items-center gap-3 mb-3">
        <div className="flex gap-0.5">
          {[...Array(review.rating)].map((_, i) => (
            <Star key={i} className="w-3.5 h-3.5 fill-gold text-gold" />
          ))}
        </div>
        <span className="text-warm-grey text-xs">{review.date}</span>
      </div>

      {/* Review text */}
      <p className="text-white/80 font-light text-sm leading-relaxed mb-5 italic">
        "{locale === 'ar' ? review.text.ar : review.text.en}"
      </p>

      {/* Helpful */}
      <div className="flex items-center gap-2 pt-4 border-t border-white/5">
        <span className="text-warm-grey text-xs">
          {locale === 'ar' ? 'هل كان هذا مفيداً؟' : 'Was this helpful?'}
        </span>
        <button
          onClick={() => { if (!voted) { setHelpful(h => h + 1); setVoted(true); } }}
          className={cn(
            'flex items-center gap-1 text-xs transition-colors px-2 py-1 border',
            voted ? 'border-gold text-gold' : 'border-white/10 text-warm-grey hover:border-white/30'
          )}
        >
          <ThumbsUp className="w-3 h-3" />
          {helpful}
        </button>
      </div>
    </motion.div>
  );
}

function ReviewsContent() {
  const { t, locale } = useI18n();
  const [activeFilter, setActiveFilter] = useState('all');

  const filters = [
    { id: 'all', label: t('reviews.allReviews') },
    { id: '5star', label: t('reviews.fiveStars') },
    { id: 'verified', label: t('reviews.verified') },
  ];

  return (
    <div className="bg-black min-h-screen pt-20">

      {/* Hero */}
      <div className="py-20 px-4 text-center border-b border-white/8">
        <span className="section-eyebrow">{t('reviews.title')}</span>
        <div className="gold-divider-center" />
        <h1 className="font-serif text-white text-4xl md:text-5xl mb-4">{t('reviews.title')}</h1>
        <p className="text-warm-grey max-w-xl mx-auto">{t('reviews.subtitle')}</p>
      </div>

      <div className="container-luxury py-16">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">

          {/* Sidebar: Overall Rating */}
          <div className="lg:col-span-1">
            <div className="bg-charcoal border border-white/8 p-8 sticky top-24">
              <p className="text-warm-grey text-xs uppercase tracking-widest mb-4">{t('reviews.overall')}</p>

              {/* Big Rating */}
              <div className="text-center mb-8">
                <div className="font-serif text-gold mb-2" style={{ fontSize: '4rem', lineHeight: 1 }}>
                  {OVERALL_RATING}
                </div>
                <div className="flex justify-center gap-1 mb-2">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-gold text-gold" />
                  ))}
                </div>
                <p className="text-warm-grey text-sm">{TOTAL_REVIEWS.toLocaleString()} {locale === 'ar' ? 'تقييم' : 'reviews'}</p>
              </div>

              {/* Breakdown Bars */}
              <div className="space-y-2.5">
                {RATING_BREAKDOWN.map(({ stars, pct }) => (
                  <div key={stars} className="flex items-center gap-3 text-xs">
                    <div className="flex gap-0.5 flex-shrink-0">
                      {[...Array(stars)].map((_, i) => (
                        <Star key={i} className="w-3 h-3 fill-gold text-gold" />
                      ))}
                    </div>
                    <div className="flex-1 bg-white/10 h-1.5 rounded-full overflow-hidden">
                      <motion.div
                        initial={{ width: 0 }}
                        whileInView={{ width: `${pct}%` }}
                        viewport={{ once: true }}
                        transition={{ duration: 1, delay: 0.2 }}
                        className="h-full bg-gold"
                      />
                    </div>
                    <span className="text-warm-grey w-8 text-right">{pct}%</span>
                  </div>
                ))}
              </div>

              {/* Write Review CTA */}
              <div className="mt-8">
                <a
                  href="https://g.page/r/transform-egypt/review"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn btn-shop w-full justify-center"
                >
                  {t('reviews.writeReview')}
                </a>
                <p className="text-warm-grey text-xs text-center mt-3">
                  {locale === 'ar' ? 'يُنشر بعد المراجعة' : 'Published after review'}
                </p>
              </div>
            </div>
          </div>

          {/* Reviews List */}
          <div className="lg:col-span-2">
            {/* Filter Tabs */}
            <div className="flex items-center gap-2 mb-8 flex-wrap">
              {filters.map(f => (
                <button
                  key={f.id}
                  onClick={() => setActiveFilter(f.id)}
                  className={cn(
                    'px-4 py-2 text-xs uppercase tracking-wider border transition-all',
                    activeFilter === f.id ? 'border-gold bg-gold/10 text-gold' : 'border-white/10 text-warm-grey hover:border-white/25'
                  )}
                >
                  {f.label}
                </button>
              ))}
            </div>

            {/* Review Cards */}
            <div className="space-y-4">
              {TESTIMONIALS.map((review, i) => (
                <ReviewCard key={review.id} review={review} index={i} />
              ))}
            </div>

            {/* Google Reviews CTA */}
            <div className="mt-10 text-center p-8 border border-white/8">
              <p className="text-white font-serif text-lg mb-2">
                {locale === 'ar' ? 'شاركي تجربتك على جوجل' : 'Share your experience on Google'}
              </p>
              <p className="text-warm-grey text-sm mb-4">
                {locale === 'ar' ? 'تقييمك يساعدنا على الوصول لمزيد من العميلات' : 'Your review helps us reach more clients'}
              </p>
              <a
                href="https://g.page/r/transform-egypt/review"
                target="_blank"
                rel="noopener noreferrer"
                className="btn btn-secondary inline-flex gap-2"
              >
                <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                  <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                  <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
                  <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
                </svg>
                {locale === 'ar' ? 'اكتبي تقييماً على جوجل' : 'Write a Google Review'}
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function ReviewsPage() {
  return (
    <I18nProvider>
      <Navigation />
      <main id="main-content">
        <ReviewsContent />
      </main>
      <Footer />
      <WhatsAppButton />
    </I18nProvider>
  );
}
