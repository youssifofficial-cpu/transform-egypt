'use client';

import Image from 'next/image';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { Clock, ArrowRight, CheckCircle } from 'lucide-react';
import { I18nProvider, useI18n } from '@/hooks/useI18n';
import { Navigation } from '@/components/layout/Navigation';
import { Footer } from '@/components/layout/Footer';
import { WhatsAppButton } from '@/components/layout/WhatsAppButton';
import { CTASection } from '@/components/sections/CTASection';
import { SERVICES } from '@/lib/data';

const SERVICE_IMAGES: Record<string, string> = {
  'hair-extensions': '/images/services/hair-extensions.jpg',
  'lash-extensions': '/images/services/lash-extensions.jpg',
  'microblading': '/images/services/microblading.jpg',
  'skincare': '/images/services/skincare.jpg',
  'nails': '/images/services/nails.jpg',
};

function ServicesContent() {
  const { locale } = useI18n();

  return (
    <div className="bg-black min-h-screen pt-20">
      {/* Hero */}
      <div className="py-20 px-4 text-center border-b border-white/8">
        <span className="section-eyebrow">{locale === 'ar' ? 'خدماتنا المميزة' : 'Signature Services'}</span>
        <div className="gold-divider-center" />
        <h1 className="font-serif text-white text-4xl md:text-5xl mb-4">
          {locale === 'ar' ? 'خدماتنا المميزة' : 'Signature Services'}
        </h1>
        <p className="text-warm-grey max-w-xl mx-auto">
          {locale === 'ar' ? 'جمال بمستوى المشاهير، مصمم خصيصاً لك' : 'Celebrity-level beauty, tailored for you'}
        </p>
      </div>

      {/* Services */}
      <div className="container-luxury py-16 space-y-20">
        {SERVICES.map((service, index) => (
          <motion.section
            key={service.id}
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            id={service.slug}
            className={`flex flex-col ${index % 2 === 0 ? 'lg:flex-row' : 'lg:flex-row-reverse'} gap-12 items-center`}
          >
            {/* Image */}
            <div className="relative w-full lg:w-1/2 aspect-[4/3] overflow-hidden">
              <Image
                src={SERVICE_IMAGES[service.id] || '/images/services/default.jpg'}
                alt={locale === 'ar' ? service.name.ar : service.name.en}
                fill
                className="object-cover"
                sizes="(max-width: 1024px) 100vw, 50vw"
              />
              <div className="absolute inset-0 border border-gold/10" />
              {service.badge && (
                <div className="absolute top-4 left-4 badge-gold">{service.badge}</div>
              )}
            </div>

            {/* Content */}
            <div className="w-full lg:w-1/2 space-y-6">
              <div>
                <span className="section-eyebrow">
                  {locale === 'ar' ? 'خدمة مميزة' : 'Signature Service'}
                </span>
                <h2 className="font-serif text-white text-3xl md:text-4xl mt-2">
                  {locale === 'ar' ? service.name.ar : service.name.en}
                </h2>
              </div>

              <p className="text-warm-grey font-light leading-relaxed">
                {locale === 'ar' ? service.description.ar : service.description.en}
              </p>

              {/* Benefits */}
              <ul className="space-y-2">
                {service.benefits.map((b, i) => (
                  <li key={i} className="flex items-center gap-3 text-sm text-white/80">
                    <CheckCircle className="w-4 h-4 text-gold flex-shrink-0" />
                    {locale === 'ar' ? b.ar : b.en}
                  </li>
                ))}
              </ul>

              {/* Pricing table */}
              <div className="bg-charcoal border border-white/8 divide-y divide-white/5">
                {service.variants.slice(0, 4).map(v => (
                  <div key={v.id} className="flex justify-between items-center px-5 py-3">
                    <div>
                      <p className="text-white text-sm font-medium">
                        {locale === 'ar' ? v.name.ar : v.name.en}
                      </p>
                      <p className="text-warm-grey text-xs flex items-center gap-1 mt-0.5">
                        <Clock className="w-3 h-3" /> {v.duration} {locale === 'ar' ? 'دقيقة' : 'min'}
                      </p>
                    </div>
                    <span className="font-serif text-gold font-semibold">
                      EGP {v.price.toLocaleString()}
                    </span>
                  </div>
                ))}
              </div>

              <div className="flex gap-3">
                <Link
                  href={`/book?service=${service.id}`}
                  className="btn btn-shop inline-flex gap-2"
                >
                  {locale === 'ar' ? 'احجز الآن' : 'Book Now'}
                  <ArrowRight className="w-4 h-4" />
                </Link>
                <Link href="/contact" className="btn btn-ghost inline-flex gap-2">
                  {locale === 'ar' ? 'استشارة مجانية' : 'Free Consultation'}
                </Link>
              </div>
            </div>
          </motion.section>
        ))}
      </div>

      <CTASection />
    </div>
  );
}

export default function ServicesPage() {
  return (
    <I18nProvider>
      <Navigation />
      <main id="main-content">
        <ServicesContent />
      </main>
      <Footer />
      <WhatsAppButton />
    </I18nProvider>
  );
}
