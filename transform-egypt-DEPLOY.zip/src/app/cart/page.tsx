'use client';

import { useState } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { motion, AnimatePresence } from 'framer-motion';
import { Minus, Plus, Trash2, ShoppingBag, Tag, Lock, Truck, RotateCcw, ArrowRight } from 'lucide-react';
import { I18nProvider, useI18n } from '@/hooks/useI18n';
import { Navigation } from '@/components/layout/Navigation';
import { Footer } from '@/components/layout/Footer';
import { WhatsAppButton } from '@/components/layout/WhatsAppButton';
import { useCartStore } from '@/store/cart';
import { cn } from '@/lib/utils';

function CartContent() {
  const { t, locale } = useI18n();
  const { items, subtotal, shipping, discount, total, itemCount, couponCode, removeItem, updateQuantity, applyCoupon, removeCoupon } = useCartStore();
  const [couponInput, setCouponInput] = useState('');
  const [couponError, setCouponError] = useState('');
  const [couponLoading, setCouponLoading] = useState(false);

  const handleApplyCoupon = async () => {
    setCouponLoading(true);
    setCouponError('');
    const valid = await applyCoupon(couponInput);
    if (!valid) {
      setCouponError(locale === 'ar' ? 'كود الخصم غير صالح' : 'Invalid coupon code');
    }
    setCouponLoading(false);
  };

  if (items.length === 0) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center py-20 px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center max-w-md"
        >
          <ShoppingBag className="w-16 h-16 text-warm-grey/30 mx-auto mb-6" />
          <h2 className="font-serif text-white text-2xl mb-3">{t('cart.empty')}</h2>
          <p className="text-warm-grey mb-8">{t('cart.emptyDesc')}</p>
          <Link href="/boutique" className="btn btn-shop inline-flex gap-2">
            {t('cart.continueShopping')}
            <ArrowRight className="w-4 h-4" />
          </Link>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="container-luxury py-12">
      <div className="mb-8">
        <h1 className="font-serif text-white text-3xl">{t('cart.title')}</h1>
        <p className="text-warm-grey text-sm mt-1">{itemCount} {locale === 'ar' ? 'منتج' : 'items'}</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">

        {/* Cart Items */}
        <div className="lg:col-span-2 space-y-4">
          <AnimatePresence>
            {items.map(item => (
              <motion.div
                key={item.id}
                layout
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20, height: 0 }}
                className="bg-charcoal border border-white/8 p-5 flex gap-5"
              >
                {/* Product Image */}
                <div className="relative w-20 h-20 flex-shrink-0 bg-ivory overflow-hidden">
                  <Image
                    src={item.product.images[0] || '/images/products/placeholder.jpg'}
                    alt={locale === 'ar' ? item.product.name.ar : item.product.name.en}
                    fill
                    className="object-cover"
                    sizes="80px"
                  />
                </div>

                {/* Details */}
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between items-start gap-4">
                    <div>
                      <h3 className="text-white text-sm font-medium line-clamp-2">
                        {locale === 'ar' ? item.product.name.ar : item.product.name.en}
                      </h3>
                      {item.selectedColor && (
                        <p className="text-warm-grey text-xs mt-0.5">
                          {locale === 'ar' ? item.selectedColor.name.ar : item.selectedColor.name.en}
                        </p>
                      )}
                      {item.selectedLength && (
                        <p className="text-warm-grey text-xs">{item.selectedLength.label}</p>
                      )}
                    </div>
                    <button
                      onClick={() => removeItem(item.id)}
                      className="text-warm-grey hover:text-red-400 transition-colors p-1 flex-shrink-0"
                      aria-label={t('cart.remove')}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="flex items-center justify-between mt-3">
                    {/* Quantity */}
                    <div className="flex items-center border border-white/15">
                      <button
                        onClick={() => updateQuantity(item.id, item.quantity - 1)}
                        className="w-8 h-8 flex items-center justify-center text-warm-grey hover:text-white transition-colors"
                        aria-label="Decrease quantity"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="w-8 text-center text-white text-sm">{item.quantity}</span>
                      <button
                        onClick={() => updateQuantity(item.id, item.quantity + 1)}
                        className="w-8 h-8 flex items-center justify-center text-warm-grey hover:text-white transition-colors"
                        aria-label="Increase quantity"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>

                    {/* Subtotal */}
                    <span className="font-serif text-gold font-semibold">
                      EGP {item.subtotal.toLocaleString()}
                    </span>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>

          <Link href="/boutique" className="inline-flex items-center gap-2 text-warm-grey hover:text-gold transition-colors text-sm mt-2">
            ← {t('cart.continueShopping')}
          </Link>
        </div>

        {/* Order Summary */}
        <div className="lg:col-span-1">
          <div className="bg-charcoal border border-white/8 p-6 sticky top-24">
            <h2 className="font-serif text-white text-lg mb-6">
              {locale === 'ar' ? 'ملخص الطلب' : 'Order Summary'}
            </h2>

            {/* Coupon */}
            <div className="mb-6">
              {couponCode ? (
                <div className="flex items-center justify-between bg-green-900/20 border border-green-600/30 px-3 py-2">
                  <span className="text-green-400 text-xs flex items-center gap-1.5">
                    <Tag className="w-3 h-3" /> {couponCode}
                  </span>
                  <button onClick={removeCoupon} className="text-warm-grey hover:text-red-400 text-xs">
                    ✕
                  </button>
                </div>
              ) : (
                <div>
                  <div className="flex gap-0">
                    <input
                      value={couponInput}
                      onChange={e => { setCouponInput(e.target.value.toUpperCase()); setCouponError(''); }}
                      placeholder={t('cart.couponCode')}
                      className="flex-1 input-luxury-box text-sm py-2.5"
                      onKeyDown={e => e.key === 'Enter' && handleApplyCoupon()}
                    />
                    <button
                      onClick={handleApplyCoupon}
                      disabled={couponLoading || !couponInput}
                      className="btn btn-shop btn-sm flex-shrink-0 disabled:opacity-40"
                    >
                      {t('cart.apply')}
                    </button>
                  </div>
                  {couponError && <p className="text-red-400 text-xs mt-1">{couponError}</p>}
                  <p className="text-warm-grey/50 text-xs mt-1">
                    {locale === 'ar' ? 'جربي: TRANSFORM10' : 'Try: TRANSFORM10'}
                  </p>
                </div>
              )}
            </div>

            {/* Price breakdown */}
            <div className="space-y-3 mb-6 pb-6 border-b border-white/8">
              <div className="flex justify-between text-sm">
                <span className="text-warm-grey">{t('cart.subtotal')}</span>
                <span className="text-white">EGP {subtotal.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-warm-grey">{t('cart.shipping')}</span>
                <span className={shipping === 0 ? 'text-green-400 font-medium' : 'text-white'}>
                  {shipping === 0 ? t('cart.free') : `EGP ${shipping}`}
                </span>
              </div>
              {discount > 0 && (
                <div className="flex justify-between text-sm">
                  <span className="text-warm-grey">{t('cart.discount')}</span>
                  <span className="text-green-400 font-medium">-EGP {discount.toLocaleString()}</span>
                </div>
              )}
            </div>

            <div className="flex justify-between mb-6">
              <span className="text-white font-semibold">{t('cart.total')}</span>
              <span className="font-serif text-gold font-bold text-xl">EGP {total.toLocaleString()}</span>
            </div>

            <Link href="/checkout" className="btn btn-shop w-full justify-center mb-3">
              {t('cart.checkout')}
              <ArrowRight className="w-4 h-4" />
            </Link>

            {/* Trust badges */}
            <div className="grid grid-cols-3 gap-2 mt-4">
              {[
                { icon: Lock, label: locale === 'ar' ? 'آمن' : 'Secure' },
                { icon: Truck, label: locale === 'ar' ? 'شحن مجاني' : 'Free Ship' },
                { icon: RotateCcw, label: locale === 'ar' ? 'إرجاع سهل' : 'Easy Return' },
              ].map(({ icon: Icon, label }) => (
                <div key={label} className="flex flex-col items-center gap-1 text-center">
                  <Icon className="w-4 h-4 text-gold" />
                  <span className="text-warm-grey text-[10px] uppercase tracking-wider">{label}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function CartPage() {
  return (
    <I18nProvider>
      <Navigation />
      <main id="main-content" className="bg-black min-h-screen pt-20">
        <CartContent />
      </main>
      <Footer />
      <WhatsAppButton />
    </I18nProvider>
  );
}
