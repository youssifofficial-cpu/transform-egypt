'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { MapPin, Phone, MessageCircle, Mail, Clock, CheckCircle, ChevronDown } from 'lucide-react';
import { I18nProvider, useI18n } from '@/hooks/useI18n';
import { Navigation } from '@/components/layout/Navigation';
import { Footer } from '@/components/layout/Footer';
import { WhatsAppButton } from '@/components/layout/WhatsAppButton';
import { BRANCHES, PHONE_1, PHONE_2, EMAIL, WHATSAPP_NUMBER, SERVICES } from '@/lib/data';
import { cn } from '@/lib/utils';

const contactSchema = z.object({
  name: z.string().min(2),
  email: z.string().email(),
  phone: z.string().min(10),
  service: z.string().optional(),
  message: z.string().min(10),
});
type ContactForm = z.infer<typeof contactSchema>;

const FAQS = [
  {
    en: { q: 'How do I book an appointment?', a: 'You can book online through our booking page, via WhatsApp at +20 100 978 0008, or by calling us directly. We recommend booking at least 3-5 days in advance.' },
    ar: { q: 'كيف أحجز موعداً؟', a: 'يمكنك الحجز عبر الإنترنت من خلال صفحة الحجز لدينا، أو عبر واتساب على +20 100 978 0008، أو بالاتصال بنا مباشرة. نوصي بالحجز قبل 3-5 أيام على الأقل.' },
  },
  {
    en: { q: 'What payment methods do you accept?', a: 'We accept cash, Visa, Mastercard, and mobile wallets (Vodafone Cash, Orange Cash). Payment is due at time of service.' },
    ar: { q: 'ما طرق الدفع المقبولة؟', a: 'نقبل النقد وفيزا وماستركارد والمحافظ الإلكترونية (فودافون كاش وأورانج كاش). يُسدَّد الدفع وقت الخدمة.' },
  },
  {
    en: { q: 'Do you offer a free consultation?', a: 'Yes! First-time clients receive a complimentary 15-minute consultation to discuss your hair goals and recommend the best service for you.' },
    ar: { q: 'هل تقدمون استشارة مجانية؟', a: 'نعم! تحصل العميلات للمرة الأولى على استشارة مجانية لمدة 15 دقيقة لمناقشة أهداف شعرك والتوصية بأفضل خدمة لك.' },
  },
  {
    en: { q: 'What is your cancellation policy?', a: 'We require 24 hours notice for cancellations. Late cancellations or no-shows may be subject to a cancellation fee.' },
    ar: { q: 'ما سياسة الإلغاء لديكم؟', a: 'نطلب إشعاراً قبل 24 ساعة للإلغاء. قد يخضع الإلغاء المتأخر أو عدم الحضور لرسوم إلغاء.' },
  },
  {
    en: { q: 'How long do hair extensions last?', a: 'With proper care, tape-in extensions last 6-8 months, keratin bonds last 3-6 months, and can be reapplied multiple times.' },
    ar: { q: 'كم تدوم وصلات الشعر؟', a: 'مع العناية المناسبة، تدوم الوصلات اللاصقة 6-8 أشهر، ووصلات الكيراتين 3-6 أشهر، ويمكن إعادة تركيبها عدة مرات.' },
  },
];

function FAQItem({ faq, locale, index }: { faq: typeof FAQS[0]; locale: string; index: number }) {
  const [open, setOpen] = useState(false);
  const item = locale === 'ar' ? faq.ar : faq.en;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay: index * 0.08 }}
      className="border-b border-white/8"
    >
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex items-center justify-between py-5 text-start"
        aria-expanded={open}
      >
        <span className={cn('font-medium text-sm transition-colors', open ? 'text-gold' : 'text-white')}>
          {item.q}
        </span>
        <ChevronDown className={cn('w-4 h-4 text-warm-grey flex-shrink-0 transition-transform duration-300', open && 'rotate-180')} />
      </button>
      {open && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          exit={{ opacity: 0, height: 0 }}
          className="pb-5"
        >
          <p className="text-warm-grey text-sm font-light leading-relaxed">{item.a}</p>
        </motion.div>
      )}
    </motion.div>
  );
}

function ContactContent() {
  const { t, locale } = useI18n();
  const [sent, setSent] = useState(false);

  const { register, handleSubmit, formState: { errors, isSubmitting }, reset } = useForm<ContactForm>({
    resolver: zodResolver(contactSchema),
  });

  const onSubmit = async () => {
    await new Promise(r => setTimeout(r, 1000));
    setSent(true);
    reset();
    setTimeout(() => setSent(false), 4000);
  };

  return (
    <div className="bg-black min-h-screen pt-20">
      {/* Hero */}
      <div className="py-20 px-4 text-center border-b border-white/8">
        <span className="section-eyebrow">{t('contact.title')}</span>
        <div className="gold-divider-center" />
        <h1 className="font-serif text-white text-4xl md:text-5xl mb-4">{t('contact.title')}</h1>
        <p className="text-warm-grey">{t('contact.subtitle')}</p>
      </div>

      <div className="container-luxury py-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">

          {/* Left: Contact Info + Branches */}
          <div>
            {/* Contact Details */}
            <div className="space-y-6 mb-12">
              <a href={`tel:+2${PHONE_1}`} className="flex items-center gap-4 group">
                <div className="w-12 h-12 border border-gold/30 flex items-center justify-center group-hover:bg-gold/10 transition-colors">
                  <Phone className="w-5 h-5 text-gold" />
                </div>
                <div>
                  <p className="text-warm-grey text-xs uppercase tracking-wider">{t('contact.phone')}</p>
                  <p className="text-white font-medium">{PHONE_1} / {PHONE_2}</p>
                </div>
              </a>

              <a href={`https://wa.me/${WHATSAPP_NUMBER}`} target="_blank" rel="noopener noreferrer" className="flex items-center gap-4 group">
                <div className="w-12 h-12 border border-gold/30 flex items-center justify-center group-hover:bg-gold/10 transition-colors">
                  <MessageCircle className="w-5 h-5 text-gold" />
                </div>
                <div>
                  <p className="text-warm-grey text-xs uppercase tracking-wider">{t('contact.whatsapp')}</p>
                  <p className="text-white font-medium">+20 {PHONE_1}</p>
                </div>
              </a>

              <a href={`mailto:${EMAIL}`} className="flex items-center gap-4 group">
                <div className="w-12 h-12 border border-gold/30 flex items-center justify-center group-hover:bg-gold/10 transition-colors">
                  <Mail className="w-5 h-5 text-gold" />
                </div>
                <div>
                  <p className="text-warm-grey text-xs uppercase tracking-wider">{t('contact.email')}</p>
                  <p className="text-white font-medium">{EMAIL}</p>
                </div>
              </a>

              <div className="flex items-center gap-4">
                <div className="w-12 h-12 border border-gold/30 flex items-center justify-center">
                  <Clock className="w-5 h-5 text-gold" />
                </div>
                <div>
                  <p className="text-warm-grey text-xs uppercase tracking-wider">{t('contact.hours')}</p>
                  <p className="text-white font-medium">{t('contact.hoursValue')}</p>
                </div>
              </div>
            </div>

            {/* Branches */}
            <div>
              <h2 className="font-serif text-white text-xl mb-5">{t('branches.title')}</h2>
              <div className="space-y-3">
                {BRANCHES.map(branch => (
                  <a
                    key={branch.id}
                    href={branch.mapUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-start gap-3 group hover:text-gold transition-colors p-4 border border-white/8 hover:border-gold/30"
                  >
                    <MapPin className="w-4 h-4 text-gold mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="text-white text-sm font-medium group-hover:text-gold transition-colors">
                        {locale === 'ar' ? branch.name.ar : branch.name.en}
                      </p>
                      <p className="text-warm-grey text-xs mt-0.5">
                        {locale === 'ar' ? branch.detail.ar : branch.detail.en}
                      </p>
                    </div>
                  </a>
                ))}
              </div>
            </div>
          </div>

          {/* Right: Contact Form */}
          <div>
            <h2 className="font-serif text-white text-2xl mb-8">
              {locale === 'ar' ? 'أرسلي لنا رسالة' : 'Send Us a Message'}
            </h2>

            <form onSubmit={handleSubmit(onSubmit)} className="space-y-5">
              <div>
                <label className="text-warm-grey text-xs uppercase tracking-wider mb-2 block">{t('contact.name')} *</label>
                <input {...register('name')} className="input-luxury-box" placeholder={locale === 'ar' ? 'اسمك الكامل' : 'Your full name'} />
                {errors.name && <p className="text-red-400 text-xs mt-1">{locale === 'ar' ? 'الاسم مطلوب' : 'Name required'}</p>}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div>
                  <label className="text-warm-grey text-xs uppercase tracking-wider mb-2 block">{t('booking.email')} *</label>
                  <input {...register('email')} type="email" className="input-luxury-box" placeholder="your@email.com" />
                  {errors.email && <p className="text-red-400 text-xs mt-1">{t('misc.invalidEmail')}</p>}
                </div>
                <div>
                  <label className="text-warm-grey text-xs uppercase tracking-wider mb-2 block">{t('booking.phone')} *</label>
                  <input {...register('phone')} type="tel" className="input-luxury-box" placeholder="01XXXXXXXXX" />
                  {errors.phone && <p className="text-red-400 text-xs mt-1">{t('misc.invalidPhone')}</p>}
                </div>
              </div>

              <div>
                <label className="text-warm-grey text-xs uppercase tracking-wider mb-2 block">
                  {locale === 'ar' ? 'الخدمة المطلوبة' : 'Service of Interest'}
                </label>
                <select {...register('service')} className="input-luxury-box cursor-pointer">
                  <option value="">{locale === 'ar' ? 'اختاري خدمة (اختياري)' : 'Select a service (optional)'}</option>
                  {SERVICES.map(s => (
                    <option key={s.id} value={s.id}>{locale === 'ar' ? s.name.ar : s.name.en}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-warm-grey text-xs uppercase tracking-wider mb-2 block">{t('contact.message')} *</label>
                <textarea
                  {...register('message')}
                  rows={5}
                  className="input-luxury-box resize-none"
                  placeholder={locale === 'ar' ? 'كيف يمكننا مساعدتك؟' : 'How can we help you?'}
                />
                {errors.message && <p className="text-red-400 text-xs mt-1">{t('misc.requiredField')}</p>}
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className={cn(
                  'btn w-full justify-center',
                  sent ? 'bg-green-600 border-green-600 text-white' : 'btn-shop'
                )}
              >
                {sent ? (
                  <><CheckCircle className="w-4 h-4" /> {t('contact.successMsg')}</>
                ) : isSubmitting ? (
                  <span className="flex items-center gap-2">
                    <span className="w-4 h-4 border-2 border-black/30 border-t-black rounded-full animate-spin" />
                    {locale === 'ar' ? 'جاري الإرسال...' : 'Sending...'}
                  </span>
                ) : t('contact.send')}
              </button>
            </form>
          </div>
        </div>

        {/* FAQ Section */}
        <div className="mt-20">
          <div className="text-center mb-10">
            <h2 className="font-serif text-white text-3xl">{t('contact.faq')}</h2>
            <div className="gold-divider-center mt-4" />
          </div>
          <div className="max-w-2xl mx-auto">
            {FAQS.map((faq, i) => (
              <FAQItem key={i} faq={faq} locale={locale} index={i} />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

export default function ContactPage() {
  return (
    <I18nProvider>
      <Navigation />
      <main id="main-content">
        <ContactContent />
      </main>
      <Footer />
      <WhatsAppButton />
    </I18nProvider>
  );
}
