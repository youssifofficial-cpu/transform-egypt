'use client';

import { useRef } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { motion, useScroll, useTransform } from 'framer-motion';
import { ChevronDown } from 'lucide-react';
import { useI18n } from '@/hooks/useI18n';

const fadeUp = (delay = 0) => ({
  initial: { opacity: 0, y: 32 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.9, ease: [0.25, 0.46, 0.45, 0.94], delay },
});

export function HeroSection() {
  const { t, locale } = useI18n();
  const containerRef = useRef<HTMLElement>(null);

  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ['start start', 'end start'],
  });

  // Parallax: background moves slower than content
  const bgY = useTransform(scrollYProgress, [0, 1], ['0%', '25%']);
  const contentY = useTransform(scrollYProgress, [0, 1], ['0%', '15%']);
  const opacity = useTransform(scrollYProgress, [0, 0.7], [1, 0]);

  return (
    <section
      ref={containerRef}
      className="relative h-screen min-h-[700px] w-full flex items-center justify-center overflow-hidden"
      aria-label="Hero section"
      id="main-content"
    >
      {/* Parallax Background */}
      <motion.div
        style={{ y: bgY }}
        className="absolute inset-0 w-full h-[115%] -top-[7.5%]"
      >
        <Image
          src="/images/hero-bg.png"
          alt="TransforM Egypt luxury hair salon - professional hair extension service"
          fill
          priority
          quality={90}
          className="object-cover object-center"
          sizes="100vw"
        />
        {/* Multi-layer overlay for cinematic effect */}
        <div className="absolute inset-0 bg-hero-overlay" />
        <div className="absolute inset-0 bg-gradient-to-r from-black/50 via-transparent to-black/30" />
        {/* Subtle grain overlay */}
        <div className="absolute inset-0 opacity-[0.03] pointer-events-none" style={{
          backgroundImage: 'url("data:image/svg+xml,%3Csvg viewBox=\'0 0 200 200\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cfilter id=\'n\'%3E%3CfeTurbulence type=\'fractalNoise\' baseFrequency=\'0.9\' numOctaves=\'4\' stitchTiles=\'stitch\'/%3E%3C/filter%3E%3Crect width=\'100%25\' height=\'100%25\' filter=\'url(%23n)\'/%3E%3C/svg%3E")',
          backgroundRepeat: 'repeat',
          backgroundSize: '200px 200px',
        }} />
      </motion.div>

      {/* Content */}
      <motion.div
        style={{ y: contentY, opacity }}
        className="relative z-10 container-luxury text-center"
      >
        <div className="max-w-5xl mx-auto px-4">

          {/* Eyebrow */}
          <motion.div {...fadeUp(0.2)} className="mb-6">
            <span className="inline-flex items-center gap-3 text-gold font-serif italic text-xl md:text-2xl">
              <span className="hidden md:block w-12 h-[1px] bg-gold/60" />
              {t('hero.tagline')}
              <span className="hidden md:block w-12 h-[1px] bg-gold/60" />
            </span>
          </motion.div>

          {/* Main Title */}
          <motion.h1
            {...fadeUp(0.4)}
            className="font-serif text-gold mb-6 text-balance"
            style={{ fontSize: 'clamp(2.2rem, 5.5vw, 4.2rem)', lineHeight: '1.1', letterSpacing: '-0.02em' }}
          >
            {t('hero.title')}
          </motion.h1>

          {/* Subtitle */}
          <motion.p
            {...fadeUp(0.6)}
            className="text-white/85 font-light mb-12 max-w-2xl mx-auto"
            style={{ fontSize: 'clamp(1rem, 2vw, 1.3rem)', lineHeight: '1.6' }}
          >
            {t('hero.subtitle')}
          </motion.p>

          {/* CTA Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.8 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4"
          >
            <Link href="/book" className="btn btn-primary btn-lg w-full sm:w-auto sm:min-w-[200px]">
              {t('hero.cta1')}
            </Link>
            <Link href="/transformations" className="btn btn-secondary btn-lg w-full sm:w-auto sm:min-w-[200px]">
              {t('hero.cta2')}
            </Link>
            <Link href="/boutique" className="btn btn-shop btn-lg w-full sm:w-auto sm:min-w-[200px]">
              {t('hero.cta3')}
            </Link>
          </motion.div>

          {/* Trust Indicators */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.2, duration: 0.8 }}
            className="flex items-center justify-center gap-6 mt-12 text-white/50 text-xs tracking-[0.15em] uppercase font-medium"
          >
            <span className="flex items-center gap-1.5">
              <span className="text-gold">★★★★★</span> 4.9 Google
            </span>
            <span className="w-1 h-1 rounded-full bg-white/30" />
            <span>30+ {locale === 'ar' ? 'سنة' : 'Years'}</span>
            <span className="w-1 h-1 rounded-full bg-white/30 hidden sm:block" />
            <span className="hidden sm:block">5,000+ {locale === 'ar' ? 'عميلة' : 'Clients'}</span>
            <span className="w-1 h-1 rounded-full bg-white/30 hidden sm:block" />
            <span className="hidden sm:block">4 {locale === 'ar' ? 'فروع' : 'Branches'}</span>
          </motion.div>
        </div>
      </motion.div>

      {/* Scroll Indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5, duration: 0.8 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 flex flex-col items-center gap-2"
        aria-hidden="true"
      >
        <span className="text-white/40 text-[10px] tracking-[0.25em] uppercase">{t('hero.scrollHint')}</span>
        <motion.div
          animate={{ y: [0, 8, 0] }}
          transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
          className="text-gold/70"
        >
          <ChevronDown className="w-6 h-6" />
        </motion.div>
      </motion.div>

      {/* Bottom Gradient Fade */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-black to-transparent pointer-events-none" />
    </section>
  );
}
