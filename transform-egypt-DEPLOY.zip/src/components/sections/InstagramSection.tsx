'use client';

import Image from 'next/image';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { Instagram, ArrowRight } from 'lucide-react';
import { useI18n } from '@/hooks/useI18n';

// Static grid using uploaded service images as placeholders
const IG_POSTS = [
  { src: '/images/wigs.jpg',               alt: 'Luxury wig transformation by TransforM Egypt' },
  { src: '/images/services/hair-extensions.jpg', alt: 'Hair extensions before and after at TransforM Cairo' },
  { src: '/images/services/lash-extensions.jpg', alt: 'Volume lash extensions result at TransforM' },
  { src: '/images/mervat.png',             alt: 'Mervat Attalla - TransforM Egypt founder' },
  { src: '/images/services/microblading.jpg',    alt: 'Microblading brow styling at TransforM Egypt' },
  { src: '/images/services/nails.jpg',          alt: 'Luxury nail art at TransforM beauty salon Cairo' },
];

export function InstagramSection() {
  const { locale } = useI18n();

  return (
    <section className="bg-[#0a0a0a] py-section" aria-labelledby="instagram-title">
      <div className="container-luxury">

        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="flex flex-col md:flex-row items-start md:items-end justify-between gap-6 mb-10"
        >
          <div>
            <h2
              id="instagram-title"
              className="font-serif text-gold mb-2"
              style={{ fontSize: 'clamp(1.75rem, 3.5vw, 2.75rem)' }}
            >
              {locale === 'ar' ? 'تابعي تحولاتنا' : 'Follow Our Transformations'}
            </h2>
            <a
              href="https://instagram.com/transformegypt"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 text-white hover:text-gold transition-colors text-lg"
            >
              <Instagram className="w-5 h-5" />
              @transformegypt
              <ArrowRight className="w-4 h-4" />
            </a>
          </div>

          <a
            href="https://instagram.com/transformegypt"
            target="_blank"
            rel="noopener noreferrer"
            className="btn btn-secondary btn-sm inline-flex gap-2 flex-shrink-0"
          >
            <Instagram className="w-4 h-4" />
            {locale === 'ar' ? 'تابعي على إنستغرام' : 'Follow on Instagram'}
          </a>
        </motion.div>

        {/* Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-2 md:gap-3">
          {IG_POSTS.map((post, index) => (
            <motion.a
              key={index}
              href="https://instagram.com/transformegypt"
              target="_blank"
              rel="noopener noreferrer"
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.07 }}
              className="group relative aspect-square overflow-hidden bg-charcoal block"
              aria-label={`View on Instagram: ${post.alt}`}
            >
              <Image
                src={post.src}
                alt={post.alt}
                fill
                className="object-cover transition-transform duration-700 ease-luxury group-hover:scale-110"
                sizes="(max-width: 768px) 50vw, 33vw"
              />
              {/* Hover Overlay */}
              <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                <Instagram className="w-9 h-9 text-white" />
              </div>
            </motion.a>
          ))}
        </div>

        {/* Follow CTA */}
        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="text-center text-warm-grey text-sm mt-8"
        >
          {locale === 'ar'
            ? 'تابعي @transformegypt لأحدث التحولات والنصائح الجمالية'
            : 'Follow @transformegypt for daily transformations & beauty tips'}
        </motion.p>
      </div>
    </section>
  );
}
