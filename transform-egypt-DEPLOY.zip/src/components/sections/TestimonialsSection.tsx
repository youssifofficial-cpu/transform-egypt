'use client';

import { useState, useEffect, useCallback, useRef } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { motion, AnimatePresence } from 'framer-motion';
import { Star, Quote, ChevronLeft, ChevronRight, ArrowRight } from 'lucide-react';
import { useI18n } from '@/hooks/useI18n';
import { TESTIMONIALS } from '@/lib/data';

export function TestimonialsSection() {
  const { t, locale } = useI18n();
  const [current, setCurrent] = useState(0);
  const [paused, setPaused] = useState(false);
  const intervalRef = useRef<NodeJS.Timeout>();

  const total = TESTIMONIALS.length;

  const goTo = useCallback((index: number) => {
    setCurrent(((index % total) + total) % total);
  }, [total]);

  const next = useCallback(() => goTo(current + 1), [current, goTo]);
  const prev = useCallback(() => goTo(current - 1), [current, goTo]);

  useEffect(() => {
    if (!paused) {
      intervalRef.current = setInterval(next, 5000);
    }
    return () => clearInterval(intervalRef.current);
  }, [paused, next]);

  const testimonial = TESTIMONIALS[current];

  return (
    <section
      className="bg-black py-section"
      aria-labelledby="testimonials-title"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
    >
      <div className="container-luxury">

        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <span className="section-eyebrow">{t('testimonials.title')}</span>
          <div className="gold-divider-center" />
          <h2 id="testimonials-title" className="section-title text-white mb-4">
            {t('testimonials.title')}
          </h2>
          <p className="section-subtitle">{t('testimonials.subtitle')}</p>
        </motion.div>

        {/* Testimonial Card */}
        <div className="max-w-4xl mx-auto">
          <div className="relative bg-charcoal border border-white/8 p-8 md:p-14">

            {/* Decorative Gold Corner */}
            <div className="absolute top-0 left-0 w-12 h-12 border-t-2 border-l-2 border-gold/40" />
            <div className="absolute bottom-0 right-0 w-12 h-12 border-b-2 border-r-2 border-gold/40" />

            <AnimatePresence mode="wait">
              <motion.div
                key={current}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.5 }}
                className="text-center"
              >
                {/* Quote Icon */}
                <Quote className="w-10 h-10 text-gold/25 mx-auto mb-8" aria-hidden="true" />

                {/* Stars */}
                <div className="flex justify-center gap-1 mb-6" aria-label={`Rating: ${testimonial.rating} out of 5 stars`}>
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-gold text-gold" />
                  ))}
                </div>

                {/* Text */}
                <blockquote
                  className="text-white font-light italic leading-relaxed mb-8 text-balance"
                  style={{ fontSize: 'clamp(1rem, 2vw, 1.2rem)' }}
                >
                  "{locale === 'ar' ? testimonial.text.ar : testimonial.text.en}"
                </blockquote>

                {/* Divider */}
                <div className="w-16 h-[1px] bg-gold/40 mx-auto mb-6" />

                {/* Client Info */}
                <div className="flex flex-col items-center gap-2">
                  {testimonial.clientPhoto && (
                    <div className="relative w-14 h-14 rounded-full overflow-hidden border-2 border-gold/40 mb-2">
                      <Image
                        src={testimonial.clientPhoto}
                        alt={locale === 'ar' ? testimonial.clientName.ar : testimonial.clientName.en}
                        fill
                        className="object-cover"
                        sizes="56px"
                      />
                    </div>
                  )}
                  <cite className="not-italic">
                    <p className="text-gold font-semibold text-base">
                      {locale === 'ar' ? testimonial.clientName.ar : testimonial.clientName.en}
                    </p>
                    <p className="text-warm-grey text-sm font-light">
                      {locale === 'ar' ? testimonial.service.ar : testimonial.service.en}
                    </p>
                  </cite>
                  {testimonial.verified && (
                    <span className="flex items-center gap-1 text-[10px] text-gold/70 uppercase tracking-wider mt-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-green-500" />
                      {t('testimonials.verified')}
                    </span>
                  )}
                </div>
              </motion.div>
            </AnimatePresence>
          </div>

          {/* Navigation */}
          <div className="flex items-center justify-center gap-6 mt-8">
            <button
              onClick={prev}
              className="w-11 h-11 border border-white/20 flex items-center justify-center text-white hover:border-gold hover:text-gold transition-all duration-300"
              aria-label="Previous testimonial"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>

            {/* Dots */}
            <div className="flex gap-2" role="tablist" aria-label="Testimonial navigation">
              {TESTIMONIALS.map((_, i) => (
                <button
                  key={i}
                  onClick={() => goTo(i)}
                  role="tab"
                  aria-selected={i === current}
                  aria-label={`Go to testimonial ${i + 1}`}
                  className={`h-1.5 rounded-full transition-all duration-300 ${
                    i === current ? 'w-8 bg-gold' : 'w-2 bg-white/20 hover:bg-white/40'
                  }`}
                />
              ))}
            </div>

            <button
              onClick={next}
              className="w-11 h-11 border border-white/20 flex items-center justify-center text-white hover:border-gold hover:text-gold transition-all duration-300"
              aria-label="Next testimonial"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>

          {/* CTA */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mt-10"
          >
            <Link href="/reviews" className="btn btn-secondary inline-flex gap-2">
              {t('testimonials.readMore')}
              <ArrowRight className="w-4 h-4" />
            </Link>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
