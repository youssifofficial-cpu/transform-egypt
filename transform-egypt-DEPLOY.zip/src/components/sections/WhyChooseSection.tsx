'use client';

import { useRef } from 'react';
import { motion, useInView } from 'framer-motion';
import { Sparkles, Users, Crown, MapPin, Gift } from 'lucide-react';
import { useI18n } from '@/hooks/useI18n';

const WHY_ITEMS = [
  { icon: Sparkles, key: 'quality' as const },
  { icon: Users,    key: 'experts' as const },
  { icon: Crown,    key: 'experience' as const },
  { icon: Crown,    key: 'celebrity' as const },
  { icon: MapPin,   key: 'location' as const },
];

export function WhyChooseSection() {
  const { t } = useI18n();
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: '-80px' });

  return (
    <section className="bg-ivory py-section" aria-labelledby="why-title">
      <div className="container-luxury">

        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="text-center mb-6"
        >
          <h2 id="why-title" className="section-title text-black mb-4">{t('why.title')}</h2>
          <p className="font-serif italic text-warm-grey text-xl">{t('why.tagline')}</p>
        </motion.div>

        <div className="gold-divider-center mb-16" />

        {/* Features Grid */}
        <div
          ref={ref}
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-8 lg:gap-6"
        >
          {WHY_ITEMS.map(({ icon: Icon, key }, index) => (
            <motion.div
              key={key}
              initial={{ opacity: 0, y: 40 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.7, delay: index * 0.1 }}
              className="flex flex-col items-center text-center group"
            >
              {/* Icon circle */}
              <div className="w-18 h-18 rounded-full bg-white shadow-card flex items-center justify-center mb-6 group-hover:shadow-gold transition-shadow duration-500"
                style={{ width: 72, height: 72 }}>
                <Icon
                  className="w-8 h-8 text-gold transition-transform duration-300 group-hover:scale-110"
                  aria-hidden="true"
                />
              </div>

              {/* Text */}
              <h3 className="font-sans font-semibold text-black text-sm uppercase tracking-[0.1em] mb-2">
                {t(`why.${key}.title`)}
              </h3>
              <p className="text-warm-grey text-sm font-light leading-relaxed">
                {t(`why.${key}.desc`)}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
