'use client';

import { useState, useRef, useCallback } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { ArrowRight, MoveHorizontal } from 'lucide-react';
import { useI18n } from '@/hooks/useI18n';
import { cn } from '@/lib/utils';

interface SliderItem {
  before: string;
  after: string;
  label: { en: string; ar: string };
  service: { en: string; ar: string };
}

const TRANSFORMATIONS: SliderItem[] = [
  {
    before: '/images/ba/hair-ext-before.jpg',
    after: '/images/services/hair-extensions.jpg',
    label: { en: 'Volume & Length Transformation', ar: 'تحول الحجم والطول' },
    service: { en: 'Russian Tape-In Extensions', ar: 'وصلات لاصقة روسية' },
  },
  {
    before: '/images/ba/lash-before.jpg',
    after: '/images/services/lash-extensions.jpg',
    label: { en: 'Lash Transformation', ar: 'تحول الرموش' },
    service: { en: 'Mega Volume Lashes', ar: 'ميغا فوليوم' },
  },
  {
    before: '/images/ba/brow-before.jpg',
    after: '/images/services/microblading.jpg',
    label: { en: 'Brow Transformation', ar: 'تحول الحواجب' },
    service: { en: 'Microblading', ar: 'مايكروبليدنج' },
  },
];

// Before/After interactive slider
function BASlider({ item, index }: { item: SliderItem; index: number }) {
  const { locale } = useI18n();
  const [position, setPosition] = useState(50);
  const containerRef = useRef<HTMLDivElement>(null);
  const dragging = useRef(false);

  const updatePosition = useCallback((clientX: number) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = Math.max(0, Math.min(clientX - rect.left, rect.width));
    setPosition((x / rect.width) * 100);
  }, []);

  const onMouseDown = () => { dragging.current = true; };
  const onMouseMove = (e: React.MouseEvent) => { if (dragging.current) updatePosition(e.clientX); };
  const onMouseUp = () => { dragging.current = false; };
  const onTouchMove = (e: React.TouchEvent) => updatePosition(e.touches[0].clientX);

  return (
    <motion.div
      initial={{ opacity: 0, y: 40 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.7, delay: index * 0.15 }}
      className="group"
    >
      {/* Slider */}
      <div
        ref={containerRef}
        className="relative aspect-[4/5] overflow-hidden cursor-col-resize select-none bg-charcoal"
        onMouseDown={onMouseDown}
        onMouseMove={onMouseMove}
        onMouseUp={onMouseUp}
        onMouseLeave={onMouseUp}
        onTouchMove={onTouchMove}
        role="img"
        aria-label={`Before and after: ${locale === 'ar' ? item.label.ar : item.label.en}`}
      >
        {/* After Image (full) */}
        <div className="absolute inset-0">
          <Image
            src={item.after}
            alt={`After: ${locale === 'ar' ? item.label.ar : item.label.en}`}
            fill
            className="object-cover pointer-events-none"
            sizes="(max-width: 768px) 100vw, 33vw"
          />
        </div>

        {/* Before Image (clipped) */}
        <div
          className="absolute inset-0 overflow-hidden"
          style={{ width: `${position}%` }}
        >
          <div className="absolute inset-0" style={{ width: `${(100 / position) * 100}%` }}>
            <Image
              src={item.before}
              alt={`Before: ${locale === 'ar' ? item.label.ar : item.label.en}`}
              fill
              className="object-cover pointer-events-none"
              sizes="(max-width: 768px) 50vw, 16vw"
            />
          </div>
        </div>

        {/* Drag Handle */}
        <div
          className="absolute top-0 bottom-0 z-10 pointer-events-none"
          style={{ left: `${position}%`, transform: 'translateX(-50%)' }}
        >
          <div className="absolute inset-y-0 left-1/2 -translate-x-1/2 w-[2px] bg-gold" />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-gold flex items-center justify-center shadow-gold">
            <MoveHorizontal className="w-5 h-5 text-black" />
          </div>
        </div>

        {/* Labels */}
        <span className="absolute top-3 left-3 z-10 bg-black/70 text-white text-[10px] uppercase tracking-widest px-2 py-1 pointer-events-none">
          {locale === 'ar' ? 'قبل' : 'Before'}
        </span>
        <span className="absolute top-3 right-3 z-10 badge-gold pointer-events-none">
          {locale === 'ar' ? 'بعد' : 'After'}
        </span>

        {/* Drag hint on first load */}
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 text-white/50 text-[10px] tracking-widest uppercase flex items-center gap-1 group-hover:opacity-0 transition-opacity pointer-events-none">
          <MoveHorizontal className="w-3 h-3" />
          {locale === 'ar' ? 'اسحبي' : 'Drag'}
        </div>
      </div>

      {/* Caption */}
      <div className="pt-5">
        <p className="font-serif text-white text-lg mb-1">
          {locale === 'ar' ? item.label.ar : item.label.en}
        </p>
        <p className="text-warm-grey text-sm font-light">
          {locale === 'ar' ? item.service.ar : item.service.en}
        </p>
      </div>
    </motion.div>
  );
}

export function TransformationsSection() {
  const { t, locale } = useI18n();

  return (
    <section className="bg-black py-section" aria-labelledby="trans-title">
      <div className="container-luxury">

        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-14"
        >
          <span className="section-eyebrow">{t('trans.title') || (locale === 'ar' ? 'تحولات حقيقية' : 'Real Transformations')}</span>
          <div className="gold-divider-center" />
          <h2 id="trans-title" className="section-title text-gold mb-4">
            {locale === 'ar' ? 'تحولات حقيقية، نتائج حقيقية' : 'Real Transformations, Real Results'}
          </h2>
          <p className="section-subtitle">
            {locale === 'ar' ? 'شاهدي الفرق — اسحبي المقبض' : 'See the TransforM difference — drag the slider'}
          </p>
        </motion.div>

        {/* Sliders grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {TRANSFORMATIONS.map((item, i) => (
            <BASlider key={i} item={item} index={i} />
          ))}
        </div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mt-12"
        >
          <Link href="/transformations" className="btn btn-secondary inline-flex gap-2">
            {locale === 'ar' ? 'عرض كل التحولات' : 'View All Transformations'}
            <ArrowRight className="w-4 h-4" />
          </Link>
        </motion.div>
      </div>
    </section>
  );
}
