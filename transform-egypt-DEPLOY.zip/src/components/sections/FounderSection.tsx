'use client';

import { useRef } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { motion, useInView } from 'framer-motion';
import { ArrowRight } from 'lucide-react';
import { useI18n } from '@/hooks/useI18n';

export function FounderSection() {
  const { t, locale } = useI18n();
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: '-100px' });

  return (
    <section className="bg-white overflow-hidden" aria-labelledby="founder-name">
      <div ref={ref} className="flex flex-col lg:flex-row min-h-[600px]">

        {/* Image Side */}
        <motion.div
          initial={{ opacity: 0, x: locale === 'ar' ? 60 : -60 }}
          animate={inView ? { opacity: 1, x: 0 } : {}}
          transition={{ duration: 0.9, ease: [0.25, 0.46, 0.45, 0.94] }}
          className="relative w-full lg:w-1/2 min-h-[500px] lg:min-h-[700px] overflow-hidden"
        >
          <Image
            src="/images/mervat.png"
            alt="Mervat Attalla — Founder & Master Beauty Artist at TransforM Egypt"
            fill
            className="object-cover object-center"
            sizes="(max-width: 1024px) 100vw, 50vw"
            quality={90}
          />
          {/* Elegant gold border overlay */}
          <div className="absolute inset-6 border border-gold/20 pointer-events-none" />
          {/* Bottom gradient */}
          <div className="absolute bottom-0 left-0 right-0 h-24 bg-gradient-to-t from-black/30 to-transparent lg:hidden" />
        </motion.div>

        {/* Content Side */}
        <motion.div
          initial={{ opacity: 0, x: locale === 'ar' ? -60 : 60 }}
          animate={inView ? { opacity: 1, x: 0 } : {}}
          transition={{ duration: 0.9, delay: 0.15, ease: [0.25, 0.46, 0.45, 0.94] }}
          className="w-full lg:w-1/2 flex flex-col justify-center px-8 py-16 lg:px-16 lg:py-24 xl:px-24"
        >
          {/* Eyebrow */}
          <span className="section-eyebrow">{t('founder.eyebrow')}</span>

          {/* Gold divider */}
          <div className="gold-divider mb-6" />

          {/* Name */}
          <h2
            id="founder-name"
            className="font-serif text-black mb-2"
            style={{ fontSize: 'clamp(2rem, 4vw, 3rem)', lineHeight: 1.1, letterSpacing: '-0.02em' }}
          >
            {t('founder.name')}
          </h2>

          {/* Title */}
          <p className="text-warm-grey text-lg font-light italic mb-8">
            {t('founder.title')}
          </p>

          {/* Story paragraphs */}
          <div className="space-y-5 mb-10">
            <p className="text-gold font-serif italic text-lg leading-relaxed">
              {t('founder.story1')}
            </p>
            <p className="text-warm-grey font-light leading-relaxed text-[0.95rem]">
              {t('founder.story2')}
            </p>
            <p className="text-warm-grey font-light leading-relaxed text-[0.95rem]">
              {t('founder.story3')}
            </p>
          </div>

          {/* Signature Line */}
          <div className="flex items-center gap-4 mb-10">
            <div className="h-[1px] w-12 bg-gold/40" />
            <span className="font-serif italic text-gold text-sm">Mervat Attalla</span>
          </div>

          {/* CTA */}
          <Link
            href="/book"
            className="btn btn-primary self-start inline-flex gap-2"
          >
            {t('founder.cta')}
            <ArrowRight className="w-4 h-4" />
          </Link>
        </motion.div>
      </div>
    </section>
  );
}
