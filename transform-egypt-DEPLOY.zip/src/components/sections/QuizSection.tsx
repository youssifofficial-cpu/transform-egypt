'use client';

import { useState } from 'react';
import Link from 'next/link';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowRight, RotateCcw } from 'lucide-react';
import { useI18n } from '@/hooks/useI18n';
import { QUIZ_RESULTS } from '@/lib/data';
import { cn } from '@/lib/utils';

const TOTAL_STEPS = 5;

function getResult(answers: number[]): keyof typeof QUIZ_RESULTS {
  if (answers[1] === 2) return 'keratin';       // Thick hair → keratin
  if (answers[2] === 2) return 'volume';         // Max volume → Indian
  return 'tape-in';                              // Default
}

export function QuizSection() {
  const { t, locale } = useI18n();
  const [step, setStep] = useState(0);
  const [answers, setAnswers] = useState<number[]>([]);
  const [done, setDone] = useState(false);

  const questions = [
    { q: t('quiz.q1.title'), opts: [t('quiz.q1.a'), t('quiz.q1.b'), t('quiz.q1.c')] },
    { q: t('quiz.q2.title'), opts: [t('quiz.q2.a'), t('quiz.q2.b'), t('quiz.q2.c')] },
    { q: t('quiz.q3.title'), opts: [t('quiz.q3.a'), t('quiz.q3.b'), t('quiz.q3.c')] },
    { q: t('quiz.q4.title'), opts: [t('quiz.q4.a'), t('quiz.q4.b'), t('quiz.q4.c')] },
    { q: t('quiz.q5.title'), opts: [t('quiz.q5.a'), t('quiz.q5.b'), t('quiz.q5.c')] },
  ];

  const handleAnswer = (idx: number) => {
    const newAnswers = [...answers, idx];
    if (step < TOTAL_STEPS - 1) {
      setAnswers(newAnswers);
      setStep(step + 1);
    } else {
      setAnswers(newAnswers);
      setDone(true);
    }
  };

  const reset = () => { setStep(0); setAnswers([]); setDone(false); };

  const resultKey = getResult(answers);
  const result = QUIZ_RESULTS[resultKey]?.[locale] ?? QUIZ_RESULTS['tape-in'][locale];

  return (
    <section className="bg-ivory py-section" aria-labelledby="quiz-title">
      <div className="container-luxury">
        <div className="max-w-2xl mx-auto">

          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <span className="section-eyebrow">{t('quiz.title')}</span>
            <div className="gold-divider-center" />
            <h2 id="quiz-title" className="section-title text-black mb-4">{t('quiz.title')}</h2>
            <p className="section-subtitle">{t('quiz.subtitle')}</p>
          </motion.div>

          {/* Card */}
          <AnimatePresence mode="wait">
            {!done ? (
              <motion.div
                key={`step-${step}`}
                initial={{ opacity: 0, x: locale === 'ar' ? -30 : 30 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: locale === 'ar' ? 30 : -30 }}
                transition={{ duration: 0.4 }}
                className="bg-white shadow-card p-8 md:p-10"
              >
                {/* Progress bar */}
                <div className="flex items-center justify-between mb-6">
                  <span className="text-warm-grey text-xs tracking-widest uppercase">
                    {t('quiz.step')} {step + 1} {t('quiz.of')} {TOTAL_STEPS}
                  </span>
                  <div className="flex gap-1.5">
                    {Array.from({ length: TOTAL_STEPS }).map((_, i) => (
                      <div
                        key={i}
                        className={cn(
                          'h-1 rounded-full transition-all duration-500',
                          i <= step ? 'bg-gold w-6' : 'bg-taupe w-3'
                        )}
                      />
                    ))}
                  </div>
                </div>

                {/* Question */}
                <h3 className="font-serif text-black text-xl md:text-2xl mb-8">
                  {questions[step]?.q}
                </h3>

                {/* Options */}
                <div className="space-y-3">
                  {questions[step]?.opts.map((opt, i) => (
                    <button
                      key={i}
                      onClick={() => handleAnswer(i)}
                      className="w-full text-start border border-taupe/80 px-5 py-4 text-sm font-medium text-black hover:border-gold hover:bg-gold/5 transition-all duration-250 group flex items-center justify-between"
                    >
                      {opt}
                      <ArrowRight className="w-4 h-4 text-warm-grey opacity-0 group-hover:opacity-100 transition-opacity" />
                    </button>
                  ))}
                </div>
              </motion.div>
            ) : (
              <motion.div
                key="result"
                initial={{ opacity: 0, scale: 0.96 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5 }}
                className="bg-black text-white p-8 md:p-12 text-center"
              >
                {/* Gold ornament */}
                <div className="text-gold text-4xl mb-4 font-serif">✦</div>
                <p className="section-eyebrow">{t('quiz.result')}</p>
                <div className="gold-divider-center mb-6" />

                <h3 className="font-serif text-3xl md:text-4xl text-white mb-4">
                  {result.title}
                </h3>
                <p className="text-warm-grey font-light leading-relaxed mb-4 max-w-md mx-auto">
                  {result.desc}
                </p>
                <p className="font-serif text-gold text-2xl mb-8">{result.price}</p>

                <div className="flex flex-col sm:flex-row gap-3 justify-center">
                  <Link href="/book" className="btn btn-shop btn-lg inline-flex gap-2">
                    {t('quiz.bookNow')}
                    <ArrowRight className="w-4 h-4" />
                  </Link>
                  <button
                    onClick={reset}
                    className="btn btn-ghost inline-flex gap-2 text-warm-grey hover:text-white"
                  >
                    <RotateCcw className="w-4 h-4" />
                    {t('quiz.startOver')}
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </section>
  );
}
