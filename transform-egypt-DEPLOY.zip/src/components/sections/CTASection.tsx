'use client';

import Image from 'next/image';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { Phone, Clock, ArrowRight } from 'lucide-react';
import { useI18n } from '@/hooks/useI18n';
import { PHONE_1, PHONE_2, WHATSAPP_NUMBER } from '@/lib/data';

export function CTASection() {
  const { t, locale } = useI18n();

  const waMsg = locale === 'ar'
    ? 'مرحباً ترانسفورم! أود حجز موعد.'
    : 'Hi TransforM! I would like to book an appointment.';

  return (
    <section className="relative py-40 overflow-hidden" aria-labelledby="cta-title">
      {/* Background */}
      <div className="absolute inset-0">
        <Image
          src="/images/hero-bg.png"
          alt="TransforM Egypt luxury salon"
          fill
          className="object-cover object-top"
          sizes="100vw"
          quality={75}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/70 to-black/80" />
        {/* Subtle gold shimmer overlay */}
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-gold/3 to-transparent" />
      </div>

      <div className="relative z-10 container-luxury">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="max-w-3xl mx-auto text-center"
        >
          {/* Ornament */}
          <div className="flex items-center justify-center gap-4 mb-6">
            <div className="h-[1px] w-12 bg-gold/50" />
            <span className="font-serif italic text-gold text-lg">{locale === 'ar' ? 'أنتِ جديدة، اليوم!' : 'A new you, Today!'}</span>
            <div className="h-[1px] w-12 bg-gold/50" />
          </div>

          {/* Title */}
          <h2
            id="cta-title"
            className="font-serif text-white mb-5 text-balance"
            style={{ fontSize: 'clamp(2rem, 5vw, 3.5rem)', lineHeight: 1.1 }}
          >
            {t('cta.title')}
          </h2>

          {/* Subtitle */}
          <p className="text-white/75 font-light text-lg mb-4 max-w-xl mx-auto leading-relaxed">
            {t('cta.subtitle')}
          </p>

          {/* Free Consultation offer */}
          <p className="text-gold font-medium mb-6 text-sm tracking-wide uppercase">
            ✦ {t('cta.offer')}
          </p>

          {/* Phone Numbers */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-4">
            <a
              href={`tel:+2${PHONE_1}`}
              className="flex items-center gap-2 font-serif text-gold text-xl hover:opacity-75 transition-opacity"
            >
              <Phone className="w-5 h-5" /> {PHONE_1}
            </a>
            <span className="text-white/20 hidden sm:block">|</span>
            <a
              href={`tel:+2${PHONE_2}`}
              className="flex items-center gap-2 font-serif text-gold text-xl hover:opacity-75 transition-opacity"
            >
              <Phone className="w-5 h-5" /> {PHONE_2}
            </a>
          </div>

          {/* Hours */}
          <p className="flex items-center justify-center gap-2 text-white/45 text-sm mb-12">
            <Clock className="w-4 h-4" />
            {t('cta.openHours')}
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link
              href="/book"
              className="btn btn-shop btn-xl w-full sm:w-auto sm:min-w-[220px] inline-flex gap-2"
            >
              {t('cta.bookOnline')}
              <ArrowRight className="w-4 h-4" />
            </Link>

            <a
              href={`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(waMsg)}`}
              target="_blank"
              rel="noopener noreferrer"
              className="btn btn-primary btn-xl w-full sm:w-auto sm:min-w-[220px] inline-flex gap-3 bg-[#25D366] border-[#25D366] hover:bg-black hover:border-[#25D366] hover:text-white"
            >
              <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
              </svg>
              {t('cta.whatsapp')}
            </a>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
