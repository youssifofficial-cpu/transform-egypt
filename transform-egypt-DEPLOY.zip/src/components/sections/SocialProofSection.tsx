'use client';

import { useRef } from 'react';
import { motion, useInView } from 'framer-motion';
import { Star, Award } from 'lucide-react';
import { useI18n } from '@/hooks/useI18n';

function AnimatedNumber({ value, suffix = '' }: { value: string; suffix?: string }) {
  return (
    <span className="font-serif text-gold" style={{ fontSize: 'clamp(2.5rem, 5vw, 3.5rem)', lineHeight: 1 }}>
      {value}
    </span>
  );
}

export function SocialProofSection() {
  const { t, locale } = useI18n();
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: '-80px' });

  const stats = [
    {
      icon: (
        <div className="flex gap-0.5 justify-center">
          {[...Array(5)].map((_, i) => (
            <Star key={i} className="w-5 h-5 fill-gold text-gold" />
          ))}
        </div>
      ),
      value: '4.9/5',
      label: t('stats.ratingLabel'),
      subtitle: t('stats.ratingSubtitle'),
    },
    {
      icon: <AnimatedNumber value={t('stats.years')} />,
      value: null,
      label: t('stats.yearsLabel'),
      subtitle: t('stats.yearsSubtitle'),
    },
    {
      icon: <AnimatedNumber value={t('stats.clients')} />,
      value: null,
      label: t('stats.clientsLabel'),
      subtitle: t('stats.clientsSubtitle'),
    },
    {
      icon: <Award className="w-12 h-12 text-gold" />,
      value: null,
      label: t('stats.celebsLabel'),
      subtitle: t('stats.celebsSubtitle'),
    },
  ];

  return (
    <section className="bg-ivory py-20 border-b border-taupe" aria-label="Social proof statistics">
      <div className="container-luxury">
        <div
          ref={ref}
          className="grid grid-cols-2 lg:grid-cols-4 gap-8 md:gap-12"
        >
          {stats.map((stat, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.7, delay: index * 0.12 }}
              className="text-center flex flex-col items-center"
            >
              {/* Icon / Number */}
              <div className="mb-4 min-h-[60px] flex items-center justify-center">
                {stat.icon}
              </div>

              {/* Label */}
              <h3 className="text-black font-semibold text-sm uppercase tracking-[0.12em] mb-1">
                {stat.label}
              </h3>

              {/* Subtitle */}
              <p className="text-warm-grey text-xs font-light">
                {stat.subtitle}
              </p>
            </motion.div>
          ))}
        </div>

        {/* Marquee Partners / Trust Bar */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={inView ? { opacity: 1 } : {}}
          transition={{ delay: 0.6, duration: 0.8 }}
          className="mt-16 pt-10 border-t border-taupe/60"
        >
          <p className="text-center text-warm-grey text-xs uppercase tracking-[0.2em] mb-6">
            {locale === 'ar' ? 'كما ظهرنا في' : 'As Seen In & Trusted By'}
          </p>
          <div className="flex items-center justify-center gap-8 md:gap-16 flex-wrap">
            {['Instagram', 'TikTok', 'Vogue Arabia', 'Cairo 360', 'Egypt Today'].map((name) => (
              <span key={name} className="text-warm-grey/50 text-xs font-medium uppercase tracking-widest">
                {name}
              </span>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
