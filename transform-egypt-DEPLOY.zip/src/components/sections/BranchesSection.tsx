'use client';

import { motion } from 'framer-motion';
import { MapPin, Phone, ExternalLink } from 'lucide-react';
import { useI18n } from '@/hooks/useI18n';
import { BRANCHES, PHONE_1, PHONE_2 } from '@/lib/data';

export function BranchesSection() {
  const { t, locale } = useI18n();

  return (
    <section className="bg-black py-section" aria-labelledby="branches-title">
      <div className="container-luxury">

        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="text-center mb-16"
        >
          <span className="section-eyebrow">{t('branches.title')}</span>
          <div className="gold-divider-center" />
          <h2 id="branches-title" className="section-title text-white mb-4">
            {t('branches.title')}
          </h2>
          <p className="section-subtitle">{t('branches.subtitle')}</p>
        </motion.div>

        {/* Branches Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {BRANCHES.map((branch, index) => (
            <motion.a
              key={branch.id}
              href={branch.mapUrl}
              target="_blank"
              rel="noopener noreferrer"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="group bg-charcoal border border-white/8 p-7 hover:border-gold/35 transition-all duration-400 flex flex-col"
              aria-label={`${locale === 'ar' ? branch.name.ar : branch.name.en} — View on Google Maps`}
            >
              {/* Pin Icon */}
              <div className="w-10 h-10 border border-gold/40 flex items-center justify-center mb-5 group-hover:bg-gold/10 transition-colors duration-300">
                <MapPin className="w-5 h-5 text-gold" aria-hidden="true" />
              </div>

              {/* Name */}
              <h3 className="font-serif text-white text-lg mb-2 group-hover:text-gold transition-colors duration-300">
                {locale === 'ar' ? branch.name.ar : branch.name.en}
              </h3>

              {/* Detail */}
              <p className="text-warm-grey text-sm font-light leading-relaxed flex-grow mb-5">
                {locale === 'ar' ? branch.detail.ar : branch.detail.en}
              </p>

              {/* Phone */}
              <a
                href={`tel:+2${branch.phone}`}
                onClick={e => e.stopPropagation()}
                className="flex items-center gap-2 text-warm-grey hover:text-gold transition-colors text-xs mb-4"
              >
                <Phone className="w-3.5 h-3.5" />
                {branch.phone}
              </a>

              {/* Map Link */}
              <span className="flex items-center gap-1.5 text-gold text-xs font-semibold uppercase tracking-[0.15em] group-hover:gap-2.5 transition-all duration-300">
                {t('branches.viewMap')}
                <ExternalLink className="w-3 h-3" />
              </span>
            </motion.a>
          ))}
        </div>

        {/* Phone CTA row */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.5 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-4 mt-12"
        >
          <a href={`tel:+2${PHONE_1}`} className="btn btn-secondary inline-flex gap-2">
            <Phone className="w-4 h-4" /> {PHONE_1}
          </a>
          <a href={`tel:+2${PHONE_2}`} className="btn btn-secondary inline-flex gap-2">
            <Phone className="w-4 h-4" /> {PHONE_2}
          </a>
        </motion.div>
      </div>
    </section>
  );
}
