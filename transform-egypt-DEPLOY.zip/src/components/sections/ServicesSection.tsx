'use client';

import { useRef } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { motion, useInView } from 'framer-motion';
import { ArrowRight } from 'lucide-react';
import { useI18n } from '@/hooks/useI18n';
import { SERVICES } from '@/lib/data';
import { cn } from '@/lib/utils';

const serviceImages: Record<string, string> = {
  'hair-extensions': '/images/services/hair-extensions.jpg',
  'lash-extensions': '/images/services/lash-extensions.jpg',
  'microblading': '/images/services/microblading.jpg',
  'skincare': '/images/services/skincare.jpg',
  'nails': '/images/services/nails.jpg',
};

function ServiceCard({
  service,
  featured = false,
  index,
}: {
  service: typeof SERVICES[0];
  featured?: boolean;
  index: number;
}) {
  const { t, locale } = useI18n();
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: '-80px' });

  return (
    <motion.article
      ref={ref}
      initial={{ opacity: 0, y: 40 }}
      animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.7, delay: index * 0.12, ease: [0.25, 0.46, 0.45, 0.94] }}
      className={cn(
        'card-product group relative overflow-hidden flex',
        featured ? 'flex-col md:flex-row md:col-span-2' : 'flex-col'
      )}
    >
      {/* Badge */}
      {service.badge && (
        <div className="absolute top-4 left-4 z-20 badge-gold">
          {locale === 'ar' ? t('services.popular') : service.badge}
        </div>
      )}

      {/* Image */}
      <div className={cn(
        'relative overflow-hidden',
        featured ? 'w-full md:w-1/2 h-72 md:h-auto min-h-[320px]' : 'h-64 w-full'
      )}>
        <Image
          src={serviceImages[service.id] || '/images/services/default.jpg'}
          alt={locale === 'ar' ? service.name.ar : service.name.en}
          fill
          className="object-cover transition-transform duration-700 ease-luxury group-hover:scale-105"
          sizes={featured ? '(max-width: 768px) 100vw, 50vw' : '(max-width: 768px) 100vw, 33vw'}
        />
        {/* Hover overlay */}
        <div className="absolute inset-0 bg-card-hover opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
      </div>

      {/* Content */}
      <div className={cn(
        'p-8 flex flex-col justify-center',
        featured ? 'md:w-1/2' : 'flex-1'
      )}>
        <h3 className={cn(
          'font-serif text-black mb-3 transition-colors duration-300 group-hover:text-gold-dark',
          featured ? 'text-2xl md:text-3xl' : 'text-xl'
        )}>
          {locale === 'ar' ? service.name.ar : service.name.en}
        </h3>

        <p className="text-warm-grey font-light leading-relaxed mb-6 text-sm flex-grow">
          {locale === 'ar' ? service.shortDescription.ar : service.shortDescription.en}
        </p>

        {/* Benefits */}
        {featured && (
          <ul className="space-y-2 mb-6">
            {service.benefits.slice(0, 3).map((b, i) => (
              <li key={i} className="flex items-center gap-2 text-sm text-warm-grey">
                <span className="w-1.5 h-1.5 bg-gold rounded-full flex-shrink-0" />
                {locale === 'ar' ? b.ar : b.en}
              </li>
            ))}
          </ul>
        )}

        <div className="flex items-center justify-between mt-auto pt-4 border-t border-taupe/60">
          <div>
            <span className="text-xs text-warm-grey uppercase tracking-wider">{t('services.from')}</span>
            <p className="price-tag font-serif text-gold font-semibold">
              EGP {service.startingPrice.toLocaleString()}
            </p>
          </div>
          <Link
            href={`/book?service=${service.id}`}
            className="btn btn-shop btn-sm group/btn"
            aria-label={`Book ${locale === 'ar' ? service.name.ar : service.name.en}`}
          >
            {t('services.bookNow')}
            <ArrowRight className="w-3 h-3 transition-transform group-hover/btn:translate-x-1" />
          </Link>
        </div>
      </div>
    </motion.article>
  );
}

export function ServicesSection() {
  const { t } = useI18n();
  const headerRef = useRef(null);
  const headerInView = useInView(headerRef, { once: true, margin: '-60px' });

  const featuredService = SERVICES.find(s => s.featured);
  const otherServices = SERVICES.filter(s => !s.featured);

  return (
    <section className="bg-white py-section" aria-labelledby="services-title">
      <div className="container-luxury">

        {/* Header */}
        <motion.div
          ref={headerRef}
          initial={{ opacity: 0, y: 30 }}
          animate={headerInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7 }}
          className="text-center mb-16"
        >
          <span className="section-eyebrow">{t('services.title')}</span>
          <div className="gold-divider-center" />
          <h2 id="services-title" className="section-title text-black mb-4">{t('services.title')}</h2>
          <p className="section-subtitle max-w-xl mx-auto">{t('services.subtitle')}</p>
        </motion.div>

        {/* Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Featured card spans 2 columns */}
          {featuredService && (
            <ServiceCard service={featuredService} featured index={0} />
          )}
          {/* Other 4 cards in 2×2 grid */}
          {otherServices.map((service, i) => (
            <ServiceCard key={service.id} service={service} index={i + 1} />
          ))}
        </div>

        {/* View All CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mt-12"
        >
          <Link href="/services" className="btn btn-primary btn-lg inline-flex gap-2">
            {t('misc.seeAll')} {t('nav.services')}
            <ArrowRight className="w-4 h-4" />
          </Link>
        </motion.div>
      </div>
    </section>
  );
}
