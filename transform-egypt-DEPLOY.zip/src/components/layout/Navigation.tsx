'use client';

import { useState, useEffect, useCallback } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X, ShoppingBag, Globe, ChevronDown } from 'lucide-react';
import { useI18n } from '@/hooks/useI18n';
import { useCartStore } from '@/store/cart';
import { cn } from '@/lib/utils';
import { WHATSAPP_NUMBER } from '@/lib/data';

const NAV_LINKS = [
  { key: 'nav.home', href: '/' },
  { key: 'nav.services', href: '/services' },
  { key: 'nav.transformations', href: '/transformations' },
  { key: 'nav.boutique', href: '/boutique' },
  { key: 'nav.reviews', href: '/reviews' },
  { key: 'nav.about', href: '/about' },
  { key: 'nav.blog', href: '/blog' },
];

export function Navigation() {
  const { t, locale, toggleLocale, dir } = useI18n();
  const { itemCount } = useCartStore();
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [activeLink, setActiveLink] = useState('/');

  useEffect(() => {
    setActiveLink(window.location.pathname);
    const handleScroll = () => setIsScrolled(window.scrollY > 60);
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Prevent body scroll when mobile menu open
  useEffect(() => {
    if (mobileOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => { document.body.style.overflow = ''; };
  }, [mobileOpen]);

  const closeMobile = useCallback(() => setMobileOpen(false), []);

  return (
    <>
      {/* Desktop / Mobile Header */}
      <header
        className={cn(
          'fixed top-0 left-0 right-0 z-50 transition-all duration-500',
          isScrolled
            ? 'bg-black/95 nav-backdrop border-b border-white/8 py-4'
            : 'bg-gradient-to-b from-black/70 to-transparent py-6'
        )}
        style={{ height: isScrolled ? '72px' : '80px' }}
      >
        <div className="container-luxury h-full">
          <div className="flex items-center justify-between h-full">

            {/* Logo */}
            <Link
              href="/"
              className="flex items-center gap-3 group flex-shrink-0"
              aria-label="TransforM Egypt - Home"
            >
              <div className="relative w-10 h-10 flex-shrink-0">
                <Image
                  src="/images/logo.png"
                  alt="TransforM T Logo"
                  fill
                  className="object-contain transition-transform duration-300 group-hover:scale-110"
                  priority
                  sizes="40px"
                />
              </div>
              <span className="font-serif text-xl tracking-[0.2em] text-white hidden sm:block">
                TransforM
              </span>
            </Link>

            {/* Desktop Navigation */}
            <nav className="hidden xl:flex items-center gap-7" aria-label="Main navigation">
              {NAV_LINKS.map(({ key, href }) => (
                <Link
                  key={href}
                  href={href}
                  className={cn(
                    'nav-link relative pb-1 group',
                    activeLink === href && 'active'
                  )}
                  onClick={() => setActiveLink(href)}
                >
                  {t(key)}
                  <span className={cn(
                    'absolute bottom-0 left-0 h-[1px] bg-gold transition-all duration-300',
                    activeLink === href ? 'w-full' : 'w-0 group-hover:w-full'
                  )} />
                </Link>
              ))}
            </nav>

            {/* Desktop Actions */}
            <div className="flex items-center gap-4">
              {/* Language Toggle */}
              <button
                onClick={toggleLocale}
                className={cn(
                  'flex items-center gap-1.5 text-xs uppercase tracking-[0.12em] font-medium transition-all duration-300',
                  'text-warm-grey hover:text-gold border border-white/15 hover:border-gold/50 px-3 py-1.5',
                  'hidden sm:flex'
                )}
                aria-label={`Switch to ${locale === 'en' ? 'Arabic' : 'English'}`}
              >
                <Globe className="w-3.5 h-3.5" />
                {locale === 'en' ? 'AR' : 'EN'}
              </button>

              {/* Cart */}
              <Link
                href="/cart"
                className="relative p-2 text-warm-grey hover:text-gold transition-colors duration-200 group"
                aria-label={`Shopping cart, ${itemCount} items`}
              >
                <ShoppingBag className="w-5 h-5 transition-transform duration-300 group-hover:scale-110" />
                {itemCount > 0 && (
                  <motion.span
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="absolute -top-1 -right-1 bg-gold text-black text-[10px] font-bold w-4.5 h-4.5 rounded-full flex items-center justify-center min-w-[18px] min-h-[18px] leading-none"
                    style={{ width: 18, height: 18 }}
                  >
                    {itemCount > 9 ? '9+' : itemCount}
                  </motion.span>
                )}
              </Link>

              {/* Book CTA */}
              <Link
                href="/book"
                className="btn btn-shop btn-sm hidden lg:flex"
                aria-label="Book an appointment"
              >
                {t('nav.book')}
              </Link>

              {/* Hamburger */}
              <button
                onClick={() => setMobileOpen(true)}
                className="xl:hidden p-2 text-white hover:text-gold transition-colors"
                aria-label="Open menu"
                aria-expanded={mobileOpen}
              >
                <Menu className="w-6 h-6" />
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {mobileOpen && (
          <>
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="fixed inset-0 z-[60] bg-black/50"
              onClick={closeMobile}
            />

            {/* Menu Panel */}
            <motion.div
              initial={{ x: dir === 'rtl' ? '-100%' : '100%' }}
              animate={{ x: 0 }}
              exit={{ x: dir === 'rtl' ? '-100%' : '100%' }}
              transition={{ type: 'tween', duration: 0.35, ease: [0.25, 0.46, 0.45, 0.94] }}
              className={cn(
                'fixed top-0 bottom-0 z-[70] w-[85vw] max-w-[420px] bg-black flex flex-col',
                dir === 'rtl' ? 'left-0' : 'right-0'
              )}
              aria-label="Mobile navigation"
            >
              {/* Header */}
              <div className="flex items-center justify-between px-6 py-6 border-b border-white/8">
                <Link href="/" onClick={closeMobile} className="flex items-center gap-3">
                  <div className="relative w-8 h-8">
                    <Image src="/images/logo.png" alt="TransforM" fill className="object-contain" sizes="32px" />
                  </div>
                  <span className="font-serif text-lg tracking-widest text-white">TransforM</span>
                </Link>
                <button
                  onClick={closeMobile}
                  className="p-2 text-warm-grey hover:text-white transition-colors"
                  aria-label="Close menu"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              {/* Nav Links */}
              <nav className="flex-1 overflow-y-auto py-8 px-6 space-y-1">
                {NAV_LINKS.map(({ key, href }, index) => (
                  <motion.div
                    key={href}
                    initial={{ opacity: 0, x: dir === 'rtl' ? -20 : 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.1 + index * 0.05 }}
                  >
                    <Link
                      href={href}
                      onClick={closeMobile}
                      className={cn(
                        'flex items-center justify-between py-4 text-2xl font-serif transition-colors duration-200 border-b border-white/5',
                        activeLink === href ? 'text-gold' : 'text-white hover:text-gold'
                      )}
                    >
                      {t(key)}
                      {activeLink === href && (
                        <span className="w-1.5 h-1.5 rounded-full bg-gold" />
                      )}
                    </Link>
                  </motion.div>
                ))}
              </nav>

              {/* Footer Actions */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
                className="px-6 py-6 border-t border-white/8 space-y-4"
              >
                <Link href="/book" onClick={closeMobile} className="btn btn-shop w-full justify-center text-base h-14">
                  {t('nav.book')}
                </Link>

                <a
                  href={`https://wa.me/${WHATSAPP_NUMBER}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn btn-ghost w-full justify-center h-12"
                  onClick={closeMobile}
                >
                  <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                  </svg>
                  WhatsApp
                </a>

                {/* Language + Social */}
                <div className="flex items-center justify-between pt-2">
                  <button
                    onClick={() => { toggleLocale(); closeMobile(); }}
                    className="flex items-center gap-2 text-warm-grey hover:text-gold transition-colors text-sm"
                  >
                    <Globe className="w-4 h-4" />
                    {locale === 'en' ? 'العربية' : 'English'}
                  </button>

                  <div className="flex items-center gap-3">
                    <a href="https://instagram.com/transformegypt" target="_blank" rel="noopener noreferrer"
                      className="w-8 h-8 border border-white/20 flex items-center justify-center text-warm-grey hover:text-gold hover:border-gold transition-all"
                      aria-label="Instagram">
                      <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z"/>
                      </svg>
                    </a>
                    <a href="https://tiktok.com/@transformegypt" target="_blank" rel="noopener noreferrer"
                      className="w-8 h-8 border border-white/20 flex items-center justify-center text-warm-grey hover:text-gold hover:border-gold transition-all"
                      aria-label="TikTok">
                      <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M19.59 6.69a4.83 4.83 0 01-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 01-2.88 2.5 2.89 2.89 0 01-2.89-2.89 2.89 2.89 0 012.89-2.89c.28 0 .54.04.79.1V9.01a6.33 6.33 0 00-.79-.05 6.34 6.34 0 00-6.34 6.34 6.34 6.34 0 006.34 6.34 6.34 6.34 0 006.33-6.34V8.69a8.27 8.27 0 004.84 1.56V6.81a4.85 4.85 0 01-1.07-.12z"/>
                      </svg>
                    </a>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}
