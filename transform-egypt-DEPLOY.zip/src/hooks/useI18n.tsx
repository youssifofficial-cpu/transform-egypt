'use client';

import { createContext, useContext, useState, useEffect, useCallback, type ReactNode } from 'react';
import { translations } from '@/lib/translations';

type Locale = 'en' | 'ar';

interface I18nContextType {
  locale: Locale;
  dir: 'ltr' | 'rtl';
  t: (path: string) => string;
  setLocale: (locale: Locale) => void;
  toggleLocale: () => void;
}

const I18nContext = createContext<I18nContextType | null>(null);

function getNestedValue(obj: Record<string, unknown>, path: string): string {
  const parts = path.split('.');
  let current: unknown = obj;
  for (const part of parts) {
    if (current && typeof current === 'object' && part in (current as Record<string, unknown>)) {
      current = (current as Record<string, unknown>)[part];
    } else {
      return path; // Return path if not found
    }
  }
  return typeof current === 'string' ? current : path;
}

export function I18nProvider({ children }: { children: ReactNode }) {
  const [locale, setLocaleState] = useState<Locale>('en');

  useEffect(() => {
    // Check localStorage or browser preference
    const stored = localStorage.getItem('transform-locale') as Locale;
    if (stored === 'en' || stored === 'ar') {
      setLocaleState(stored);
    } else {
      // Check browser language
      const browserLang = navigator.language.toLowerCase();
      if (browserLang.startsWith('ar')) {
        setLocaleState('ar');
      }
    }
  }, []);

  useEffect(() => {
    // Update HTML attributes for RTL support
    const html = document.documentElement;
    html.lang = locale;
    html.dir = locale === 'ar' ? 'rtl' : 'ltr';
    document.body.style.fontFamily = locale === 'ar'
      ? 'var(--font-cairo), Cairo, sans-serif'
      : 'var(--font-inter), Inter, sans-serif';
  }, [locale]);

  const setLocale = useCallback((newLocale: Locale) => {
    setLocaleState(newLocale);
    localStorage.setItem('transform-locale', newLocale);
  }, []);

  const toggleLocale = useCallback(() => {
    setLocale(locale === 'en' ? 'ar' : 'en');
  }, [locale, setLocale]);

  const t = useCallback((path: string): string => {
    const localeTranslations = translations[locale] as Record<string, unknown>;
    return getNestedValue(localeTranslations, path);
  }, [locale]);

  const value: I18nContextType = {
    locale,
    dir: locale === 'ar' ? 'rtl' : 'ltr',
    t,
    setLocale,
    toggleLocale,
  };

  return (
    <I18nContext.Provider value={value}>
      {children}
    </I18nContext.Provider>
  );
}

export function useI18n() {
  const context = useContext(I18nContext);
  if (!context) {
    throw new Error('useI18n must be used within I18nProvider');
  }
  return context;
}
