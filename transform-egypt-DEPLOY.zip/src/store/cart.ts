import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { Cart, CartItem, Product, ProductColor, ProductLength } from '@/types';

interface CartStore extends Cart {
  addItem: (product: Product, quantity?: number, color?: ProductColor, length?: ProductLength) => void;
  removeItem: (itemId: string) => void;
  updateQuantity: (itemId: string, quantity: number) => void;
  clearCart: () => void;
  applyCoupon: (code: string) => Promise<boolean>;
  removeCoupon: () => void;
}

function calculateCart(items: CartItem[], couponCode?: string): Omit<Cart, 'items'> {
  const subtotal = items.reduce((sum, item) => sum + item.subtotal, 0);
  const shipping = subtotal >= 1000 ? 0 : 50; // Free shipping over EGP 1000
  const discount = couponCode === 'TRANSFORM10' ? Math.round(subtotal * 0.1) : 0;
  const total = subtotal + shipping - discount;

  return {
    itemCount: items.reduce((sum, item) => sum + item.quantity, 0),
    subtotal,
    shipping,
    discount,
    total,
    couponCode,
  };
}

export const useCartStore = create<CartStore>()(
  persist(
    (set, get) => ({
      items: [],
      itemCount: 0,
      subtotal: 0,
      shipping: 0,
      discount: 0,
      total: 0,

      addItem: (product, quantity = 1, color, length) => {
        const { items } = get();
        const itemId = `${product.id}-${color?.id || 'default'}-${length?.id || 'default'}`;

        const existingItem = items.find(i => i.id === itemId);
        const basePrice = product.price + (length?.priceModifier || 0);

        let newItems: CartItem[];
        if (existingItem) {
          newItems = items.map(item =>
            item.id === itemId
              ? { ...item, quantity: item.quantity + quantity, subtotal: (item.quantity + quantity) * basePrice }
              : item
          );
        } else {
          const newItem: CartItem = {
            id: itemId,
            productId: product.id,
            product,
            quantity,
            selectedColor: color,
            selectedLength: length,
            subtotal: quantity * basePrice,
          };
          newItems = [...items, newItem];
        }

        const cartCalc = calculateCart(newItems, get().couponCode);
        set({ items: newItems, ...cartCalc });
      },

      removeItem: (itemId) => {
        const { items, couponCode } = get();
        const newItems = items.filter(i => i.id !== itemId);
        const cartCalc = calculateCart(newItems, couponCode);
        set({ items: newItems, ...cartCalc });
      },

      updateQuantity: (itemId, quantity) => {
        if (quantity < 1) return;
        const { items, couponCode } = get();
        const newItems = items.map(item =>
          item.id === itemId
            ? { ...item, quantity, subtotal: quantity * (item.product.price + (item.selectedLength?.priceModifier || 0)) }
            : item
        );
        const cartCalc = calculateCart(newItems, couponCode);
        set({ items: newItems, ...cartCalc });
      },

      clearCart: () => {
        set({ items: [], itemCount: 0, subtotal: 0, shipping: 0, discount: 0, total: 0, couponCode: undefined });
      },

      applyCoupon: async (code) => {
        const validCoupons = ['TRANSFORM10', 'BEAUTY20', 'VIP15'];
        if (validCoupons.includes(code.toUpperCase())) {
          const { items } = get();
          const cartCalc = calculateCart(items, code.toUpperCase());
          set({ ...cartCalc, couponCode: code.toUpperCase() });
          return true;
        }
        return false;
      },

      removeCoupon: () => {
        const { items } = get();
        const cartCalc = calculateCart(items, undefined);
        set({ ...cartCalc, couponCode: undefined });
      },
    }),
    {
      name: 'transform-cart',
      partialize: (state) => ({
        items: state.items,
        couponCode: state.couponCode,
      }),
      onRehydrateStorage: () => (state) => {
        if (state) {
          const cartCalc = calculateCart(state.items, state.couponCode);
          Object.assign(state, cartCalc);
        }
      },
    }
  )
);
