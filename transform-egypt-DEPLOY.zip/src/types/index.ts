// ─── Language & i18n ─────────────────────────────────────────────
export type Locale = 'en' | 'ar';
export type Direction = 'ltr' | 'rtl';

export interface LocalizedString {
  en: string;
  ar: string;
}

// ─── Products ────────────────────────────────────────────────────
export type ProductCategory =
  | 'hair-extensions'
  | 'wigs'
  | 'lash-extensions'
  | 'brows'
  | 'skincare'
  | 'nails'
  | 'makeup'
  | 'hair-care';

export type ExtensionType =
  | 'tape-in'
  | 'keratin'
  | 'micro-ring'
  | 'clip-in'
  | 'weft'
  | 'nano-ring';

export interface ProductColor {
  id: string;
  name: LocalizedString;
  hex: string;
  image?: string;
}

export interface ProductLength {
  id: string;
  label: string; // "12\"", "16\"", etc.
  cm: number;
  priceModifier: number; // EGP
}

export interface ProductReview {
  id: string;
  authorName: string;
  authorAvatar?: string;
  rating: number; // 1-5
  title?: string;
  body: string;
  date: string;
  service?: string;
  verified: boolean;
  helpful: number;
  photos?: string[];
}

export interface Product {
  id: string;
  slug: string;
  name: LocalizedString;
  shortDescription: LocalizedString;
  description: LocalizedString;
  category: ProductCategory;
  extensionType?: ExtensionType;
  price: number; // EGP
  originalPrice?: number; // For sale items
  images: string[];
  colors?: ProductColor[];
  lengths?: ProductLength[];
  inStock: boolean;
  stockCount?: number;
  badge?: 'new' | 'sale' | 'bestseller' | 'limited';
  rating: number;
  reviewCount: number;
  features: LocalizedString[];
  careInstructions?: LocalizedString[];
  howToApply?: LocalizedString[];
  faqs?: Array<{ question: LocalizedString; answer: LocalizedString }>;
  relatedProducts?: string[]; // Product IDs
  sku: string;
  weight?: number; // grams
  isDigital?: boolean;
}

// ─── Services ────────────────────────────────────────────────────
export interface ServiceVariant {
  id: string;
  name: LocalizedString;
  duration: number; // minutes
  price: number; // EGP
  description?: LocalizedString;
}

export interface Service {
  id: string;
  slug: string;
  name: LocalizedString;
  shortDescription: LocalizedString;
  description: LocalizedString;
  image: string;
  gallery?: string[];
  category: string;
  variants: ServiceVariant[];
  startingPrice: number;
  duration: number; // minutes (base duration)
  featured: boolean;
  badge?: string;
  benefits: LocalizedString[];
  process?: LocalizedString[];
  faqs?: Array<{ question: LocalizedString; answer: LocalizedString }>;
  relatedServices?: string[];
}

// ─── Booking ─────────────────────────────────────────────────────
export interface TimeSlot {
  time: string; // "10:00 AM"
  available: boolean;
}

export interface BookingFormData {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  serviceId: string;
  variantId?: string;
  date: string;
  time: string;
  technicianId?: string;
  specialRequests?: string;
  isNewClient: boolean;
}

export interface Booking {
  id: string;
  referenceNumber: string;
  status: 'pending' | 'confirmed' | 'completed' | 'cancelled';
  serviceId: string;
  variantId?: string;
  date: string;
  time: string;
  clientName: string;
  clientEmail: string;
  clientPhone: string;
  notes?: string;
  createdAt: string;
}

// ─── Cart & E-commerce ───────────────────────────────────────────
export interface CartItem {
  id: string;
  productId: string;
  product: Product;
  quantity: number;
  selectedColor?: ProductColor;
  selectedLength?: ProductLength;
  subtotal: number;
}

export interface Cart {
  items: CartItem[];
  itemCount: number;
  subtotal: number;
  shipping: number;
  discount: number;
  total: number;
  couponCode?: string;
}

export interface ShippingAddress {
  firstName: string;
  lastName: string;
  address1: string;
  address2?: string;
  city: string;
  governorate: string;
  postalCode?: string;
  country: string;
  phone: string;
}

export interface Order {
  id: string;
  orderNumber: string;
  status: 'pending' | 'confirmed' | 'processing' | 'shipped' | 'delivered' | 'cancelled';
  items: CartItem[];
  shippingAddress: ShippingAddress;
  paymentMethod: 'cod' | 'card' | 'wallet';
  subtotal: number;
  shipping: number;
  discount: number;
  total: number;
  estimatedDelivery: string;
  createdAt: string;
  trackingNumber?: string;
}

// ─── Testimonials ─────────────────────────────────────────────────
export interface Testimonial {
  id: string;
  clientName: LocalizedString;
  clientPhoto?: string;
  rating: number;
  text: LocalizedString;
  service: LocalizedString;
  date: string;
  verified: boolean;
  videoUrl?: string;
  beforePhoto?: string;
  afterPhoto?: string;
}

// ─── Blog ────────────────────────────────────────────────────────
export interface BlogPost {
  id: string;
  slug: string;
  title: LocalizedString;
  excerpt: LocalizedString;
  content: LocalizedString;
  featuredImage: string;
  category: string;
  tags: string[];
  author: {
    name: string;
    photo?: string;
    bio?: LocalizedString;
  };
  publishedAt: string;
  updatedAt?: string;
  readTime: number; // minutes
  seo: {
    title: LocalizedString;
    description: LocalizedString;
  };
}

// ─── Navigation ──────────────────────────────────────────────────
export interface NavItem {
  label: LocalizedString;
  href: string;
  children?: NavItem[];
}

// ─── Transformation Gallery ──────────────────────────────────────
export interface Transformation {
  id: string;
  beforeImage: string;
  afterImage: string;
  service: LocalizedString;
  description?: LocalizedString;
  clientName?: string;
  technicianName?: string;
  date?: string;
  category: string;
}

// ─── Analytics Events ────────────────────────────────────────────
export interface AnalyticsEvent {
  action: string;
  category: string;
  label?: string;
  value?: number;
}
