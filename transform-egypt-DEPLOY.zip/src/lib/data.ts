import type { Product, Service, Testimonial, Transformation } from '@/types';

export const WHATSAPP_NUMBER = '201009780008';
export const PHONE_1 = '01009780008';
export const PHONE_2 = '01004545700';
export const EMAIL = 'hello@transformegypt.com';
export const INSTAGRAM = 'https://instagram.com/transformegypt';
export const FACEBOOK = 'https://facebook.com/TransformEgypt';
export const TIKTOK = 'https://tiktok.com/@transformegypt';

export const BRANCHES = [
  {
    id: 'city-stars',
    name: { en: 'City Stars Mall', ar: 'سيتي ستارز مول' },
    detail: { en: 'Ground floor, Gate 7 (next to Café Supreme)', ar: 'الدور الأرضي، بوابة 7 (بجانب كافيه سوبريم)' },
    mapUrl: 'https://www.google.com/maps/search/Transform+Egypt+City+Stars+Mall+Cairo',
    phone: PHONE_1,
  },
  {
    id: 'cfc',
    name: { en: 'Cairo Festival City Mall', ar: 'كايرو فيستيفال سيتي مول' },
    detail: { en: '3rd floor (next to Casper)', ar: 'الدور الثالث (بجانب كاسبر)' },
    mapUrl: 'https://www.google.com/maps/search/Transform+Egypt+Cairo+Festival+City+Mall',
    phone: PHONE_1,
  },
  {
    id: 'sofitel',
    name: { en: 'Sofitel Downtown Cairo', ar: 'سوفيتيل داون تاون القاهرة' },
    detail: { en: 'Downstairs (next to Banque Misr)', ar: 'الدور السفلي (بجانب بنك مصر)' },
    mapUrl: 'https://www.google.com/maps/search/Transform+Egypt+Sofitel+Downtown+Cairo',
    phone: PHONE_2,
  },
  {
    id: 'ritz',
    name: { en: 'The Nile Ritz-Carlton', ar: 'ذا نايل ريتز كارلتون' },
    detail: { en: '1st floor above lobby', ar: 'الدور الأول فوق اللوبي' },
    mapUrl: 'https://www.google.com/maps/search/Transform+Egypt+Nile+Ritz+Carlton+Cairo',
    phone: PHONE_2,
  },
];

export const SERVICES: Service[] = [
  {
    id: 'hair-extensions',
    slug: 'hair-extensions',
    name: { en: 'Hair Extensions', ar: 'وصلات الشعر' },
    shortDescription: {
      en: 'Premium quality extensions for volume, length & confidence.',
      ar: 'وصلات فاخرة بجودة عالية للحجم والطول والثقة.',
    },
    description: {
      en: 'Transform your hair with our premium human hair extensions. We offer Indian, Russian, Brazilian, and Turkish hair in tape-in, keratin bond, micro-ring, and clip-in styles. Each set is custom-matched to your natural hair for seamless, undetectable results that can last 6-12 months with proper care.',
      ar: 'حولي شعرك مع وصلات الشعر الطبيعي الفاخرة. نقدم شعراً هندياً وروسياً وبرازيلياً وتركياً بتقنيات لاصقة وكيراتين ومايكرو رينج. كل مجموعة مطابقة لشعرك الطبيعي لنتائج سلسة وغير مكتشفة تدوم من 6 إلى 12 شهراً مع العناية المناسبة.',
    },
    image: '/images/services/hair-extensions.jpg',
    gallery: ['/images/services/hair-ext-1.jpg', '/images/services/hair-ext-2.jpg'],
    category: 'hair',
    variants: [
      { id: 'tape-in-60g', name: { en: 'Tape-In 60g (50cm)', ar: 'لاصقة 60g (50cm)' }, duration: 90, price: 10000 },
      { id: 'tape-in-100g', name: { en: 'Tape-In 100g (60cm)', ar: 'لاصقة 100g (60cm)' }, duration: 120, price: 11000 },
      { id: 'keratin-100g', name: { en: 'Keratin Bond 100g (70cm)', ar: 'كيراتين 100g (70cm)' }, duration: 150, price: 13000 },
      { id: 'russian-60g', name: { en: 'Russian Hair 60g', ar: 'شعر روسي 60g' }, duration: 120, price: 14000 },
      { id: 'russian-100g', name: { en: 'Russian Hair 100g', ar: 'شعر روسي 100g' }, duration: 180, price: 19000 },
      { id: 'brazilian', name: { en: 'Brazilian Hair 100g', ar: 'شعر برازيلي 100g' }, duration: 180, price: 30000 },
    ],
    startingPrice: 10000,
    duration: 90,
    featured: true,
    badge: 'MOST POPULAR',
    benefits: [
      { en: 'Instant volume and length', ar: 'حجم وطول فوري' },
      { en: '100% human hair', ar: 'شعر طبيعي 100%' },
      { en: 'Heat stylable', ar: 'قابلة للتصفيف بالحرارة' },
      { en: 'Lasts 6-12 months', ar: 'تدوم من 6 إلى 12 شهراً' },
    ],
  },
  {
    id: 'lash-extensions',
    slug: 'lash-extensions',
    name: { en: 'Lash Extensions', ar: 'تركيب رموش' },
    shortDescription: {
      en: 'Classic, volume, mega volume & fox eye sets crafted to perfection.',
      ar: 'كلاسيك، فوليوم، ميغا فوليوم ورموش فوكس بإتقان.',
    },
    description: {
      en: 'Our certified lash technicians create stunning, customized lash sets tailored to your eye shape and desired look. From natural classics to dramatic mega volume, we have the perfect lash style for every occasion.',
      ar: 'فنياتنا المعتمدات في الرموش يصنعن مجموعات رموش رائعة ومخصصة تناسب شكل عينك والمظهر المطلوب.',
    },
    image: '/images/services/lash-extensions.jpg',
    gallery: [],
    category: 'lash',
    variants: [
      { id: 'classic', name: { en: 'Classic Set', ar: 'كلاسيك' }, duration: 90, price: 1050 },
      { id: '2d', name: { en: '2D Volume', ar: '2D فوليوم' }, duration: 100, price: 1100 },
      { id: '3d', name: { en: '3D Volume', ar: '3D فوليوم' }, duration: 110, price: 1200 },
      { id: 'mega', name: { en: 'Mega Volume (6D)', ar: 'ميغا فوليوم (6D)' }, duration: 120, price: 1400 },
      { id: 'fox', name: { en: 'Fox Eye Set', ar: 'رموش فوكس' }, duration: 120, price: 1700 },
      { id: 'refill', name: { en: 'Refill (3 weeks)', ar: 'إعادة تركيب (3 أسابيع)' }, duration: 60, price: 600 },
    ],
    startingPrice: 1050,
    duration: 90,
    featured: false,
    benefits: [
      { en: 'Certified lash artists', ar: 'فنيات رموش معتمدات' },
      { en: 'Premium Korean lash fibers', ar: 'ألياف رموش كورية ممتازة' },
      { en: 'Lasts 3-4 weeks', ar: 'تدوم من 3 إلى 4 أسابيع' },
      { en: 'Safe & allergen-tested glue', ar: 'غراء آمن ومختبر من الحساسية' },
    ],
  },
  {
    id: 'microblading',
    slug: 'microblading-brows',
    name: { en: 'Microblading & Brows', ar: 'مايكروبليدنج وحواجب' },
    shortDescription: {
      en: 'Semi-permanent microblading & brow extensions for perfect arches.',
      ar: 'مايكروبليدنج شبه دائم ووصلات حواجب لأقواس مثالية.',
    },
    description: {
      en: 'Achieve perfectly defined, natural-looking brows that last 1-2 years. Our microblading technique uses ultra-fine strokes to mimic natural hair, creating brows that complement your unique facial features.',
      ar: 'احصلي على حواجب محددة ومثالية وطبيعية المظهر تدوم من 1 إلى 2 سنة.',
    },
    image: '/images/services/microblading.jpg',
    gallery: [],
    category: 'brows',
    variants: [
      { id: 'microblading', name: { en: 'Microblading (Full)', ar: 'مايكروبليدنج كامل' }, duration: 120, price: 1450 },
      { id: 'brow-ext', name: { en: 'Brow Extensions', ar: 'وصلات حواجب' }, duration: 60, price: 800 },
      { id: 'brow-shape', name: { en: 'Brow Shaping & Tint', ar: 'تشكيل وصبغ حواجب' }, duration: 45, price: 300 },
      { id: 'ombre', name: { en: 'Ombré Powder Brows', ar: 'أومبري باودر' }, duration: 150, price: 2000 },
    ],
    startingPrice: 300,
    duration: 60,
    featured: false,
    benefits: [
      { en: 'Lasts 12-24 months', ar: 'يدوم من 12 إلى 24 شهراً' },
      { en: 'Waterproof results', ar: 'نتائج مقاومة للماء' },
      { en: 'No daily makeup needed', ar: 'لا حاجة للمكياج اليومي' },
    ],
  },
  {
    id: 'skincare',
    slug: 'skin-care-facials',
    name: { en: 'Skin Care & Facials', ar: 'العناية بالبشرة' },
    shortDescription: {
      en: 'Luxury facials, dermapen & advanced skin treatments for glowing skin.',
      ar: 'فيشيال فاخر وديرمابن وعلاجات بشرة متقدمة للبشرة المتوهجة.',
    },
    description: {
      en: 'Our medical-grade skin treatments are performed by certified aestheticians using the latest technology. From dermapen to hydrafacial, we have the perfect treatment to address your skin concerns and reveal your most radiant complexion.',
      ar: 'علاجات البشرة الطبية لدينا يؤديها خبيرات تجميل معتمدات باستخدام أحدث التقنيات.',
    },
    image: '/images/services/skincare.jpg',
    gallery: [],
    category: 'skin',
    variants: [
      { id: 'dermapen', name: { en: 'Dermapen Session', ar: 'جلسة ديرمابن' }, duration: 60, price: 800 },
      { id: 'diamond', name: { en: 'Diamond Crystal Facial', ar: 'فيشيال كريستال دايموند' }, duration: 75, price: 500 },
      { id: 'lifting', name: { en: 'Lifting Massage', ar: 'مساج شد' }, duration: 60, price: 600 },
      { id: 'hydra', name: { en: 'HydraFacial', ar: 'هايدرافيشيال' }, duration: 90, price: 1200 },
      { id: 'dermaplaning', name: { en: 'Dermaplaning', ar: 'ديرمابلانينج' }, duration: 45, price: 700 },
    ],
    startingPrice: 500,
    duration: 60,
    featured: false,
    benefits: [
      { en: 'Immediate visible results', ar: 'نتائج مرئية فورية' },
      { en: 'Medical-grade equipment', ar: 'أجهزة طبية متطورة' },
      { en: 'Certified aestheticians', ar: 'خبيرات تجميل معتمدات' },
    ],
  },
  {
    id: 'nails',
    slug: 'nails-makeup',
    name: { en: 'Nails & Makeup', ar: 'أظافر ومكياج' },
    shortDescription: {
      en: 'Professional nail art, hard gel, acrylic & expert makeup services.',
      ar: 'تصميم احترافي للأظافر، هارد جل، أكريليك ومكياج خبير.',
    },
    description: {
      en: 'From natural manicures to elaborate nail art, our nail artists create stunning designs for every occasion. Our professional makeup artists specialize in bridal, event, and editorial looks.',
      ar: 'من المانيكير الطبيعي إلى تصاميم الأظافر المعقدة، يبتكر فناني الأظافر تصاميم رائعة لكل مناسبة.',
    },
    image: '/images/services/nails.jpg',
    gallery: [],
    category: 'nails',
    variants: [
      { id: 'manicure', name: { en: 'Manicure', ar: 'مانيكير' }, duration: 45, price: 150 },
      { id: 'pedicure', name: { en: 'Pedicure', ar: 'بديكير' }, duration: 60, price: 200 },
      { id: 'gel', name: { en: 'Gel Polish', ar: 'جل بوليش' }, duration: 60, price: 400 },
      { id: 'hard-gel', name: { en: 'Hard Gel Extensions', ar: 'هارد جل' }, duration: 90, price: 900 },
      { id: 'acrylic', name: { en: 'Acrylic Full Set', ar: 'أكريليك' }, duration: 90, price: 850 },
      { id: 'makeup', name: { en: 'Professional Makeup', ar: 'مكياج احترافي' }, duration: 90, price: 800 },
    ],
    startingPrice: 150,
    duration: 45,
    featured: false,
    benefits: [
      { en: 'Premium nail products', ar: 'منتجات أظافر ممتازة' },
      { en: 'Expert nail artists', ar: 'فنيات أظافر خبيرات' },
      { en: 'Long-lasting results', ar: 'نتائج طويلة الأمد' },
    ],
  },
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: '1',
    clientName: { en: 'Nour Hassan', ar: 'نور حسن' },
    clientPhoto: '/images/clients/nour.jpg',
    rating: 5,
    text: {
      en: 'TransforM completely changed my confidence! Mervat is a true artist. My tape-in extensions look completely natural and lasted over 6 months. The salon is absolutely gorgeous and the service is unmatched in Cairo.',
      ar: 'ترانسفورم غيّرت ثقتي بنفسي تماماً! ميرفت فنانة حقيقية. وصلاتي اللاصقة بدت طبيعية تماماً وأكثر من 6 أشهر. الصالون رائع والخدمة لا مثيل لها في القاهرة.',
    },
    service: { en: 'Tape-In Hair Extensions', ar: 'وصلات لاصقة' },
    date: '2024-11-15',
    verified: true,
  },
  {
    id: '2',
    clientName: { en: 'Farah Al-Rashid', ar: 'فرح الرشيد' },
    clientPhoto: '/images/clients/farah.jpg',
    rating: 5,
    text: {
      en: 'Best lash extensions I\'ve ever had in Cairo. The studio is elegant, the staff is incredibly professional, and the results are absolutely stunning. I get compliments every single day!',
      ar: 'أفضل رموش تعلتها في القاهرة على الإطلاق. ستوديو راقٍ، الفريق محترف بشكل لا يصدق، والنتائج مذهلة. أتلقى إطراءات كل يوم!',
    },
    service: { en: 'Volume Lash Extensions', ar: 'رموش فوليوم' },
    date: '2024-10-28',
    verified: true,
  },
  {
    id: '3',
    clientName: { en: 'Mariam Samir', ar: 'مريم سمير' },
    clientPhoto: '/images/clients/mariam.jpg',
    rating: 5,
    text: {
      en: 'I flew in from Dubai specifically for Mervat\'s microblading. Worth every penny and every mile! My brows have never looked this perfect in my life. The precision and artistry is truly exceptional.',
      ar: 'سافرت من دبي خصيصاً للمايكروبليدنج مع ميرفت. يستحق كل قرش وكل ميل! حواجبي لم تبدُ بهذه الجمال في حياتي. الدقة والفن استثنائيان حقاً.',
    },
    service: { en: 'Microblading & Brows', ar: 'مايكروبليدنج' },
    date: '2024-12-01',
    verified: true,
  },
  {
    id: '4',
    clientName: { en: 'Salma Khaled', ar: 'سلمى خالد' },
    clientPhoto: '/images/clients/salma.jpg',
    rating: 5,
    text: {
      en: 'The VIP experience is unmatched. From the moment you walk in, every single detail is perfect. TransforM is truly Cairo\'s #1 luxury salon — I wouldn\'t go anywhere else!',
      ar: 'تجربة VIP لا مثيل لها. من لحظة دخولك، كل تفصيلة مثالية. ترانسفورم هو حقاً الصالون الفاخر الأول في القاهرة — لن أذهب لأي مكان آخر!',
    },
    service: { en: 'Russian Hair Extensions + Lash', ar: 'وصلات روسية + رموش' },
    date: '2024-09-20',
    verified: true,
  },
  {
    id: '5',
    clientName: { en: 'Yasmine Taha', ar: 'ياسمين طه' },
    rating: 5,
    text: {
      en: 'Got my bridal package done here and I looked absolutely breathtaking on my wedding day. Hair, lashes, and makeup — all done to perfection. Thank you TransforM for making my dream look come true!',
      ar: 'حجزت باقة العروس هنا وبدوت رائعة في يوم زفافي. الشعر والرموش والمكياج — كل شيء بإتقان. شكراً ترانسفورم على تحقيق مظهر أحلامي!',
    },
    service: { en: 'Bridal Package', ar: 'باقة العروس' },
    date: '2024-08-15',
    verified: true,
  },
];

export const PRODUCTS: Product[] = [
  {
    id: 'tape-in-indian-60g',
    slug: 'tape-in-indian-hair-extensions-60g',
    name: { en: 'Tape-In Indian Hair Extensions 60g', ar: 'وصلات لاصقة - شعر هندي 60g' },
    shortDescription: { en: 'Premium Indian remy hair, 50cm, natural-looking tape-in extensions', ar: 'شعر هندي ريمي ممتاز، 50سم، وصلات لاصقة طبيعية المظهر' },
    description: { en: 'Our most popular tape-in extensions feature premium Indian remy hair for the most natural look and feel. Each set includes 20 pieces (10 strips), color matched to your natural hair.', ar: 'وصلاتنا اللاصقة الأكثر شعبية تتميز بشعر هندي ريمي ممتاز لأكثر مظهر وملمس طبيعي.' },
    category: 'hair-extensions',
    extensionType: 'tape-in',
    price: 10000,
    images: ['/images/products/tape-in-60g-1.jpg', '/images/products/tape-in-60g-2.jpg'],
    colors: [
      { id: 'dark-brown', name: { en: 'Dark Brown', ar: 'بني داكن' }, hex: '#3B2314' },
      { id: 'medium-brown', name: { en: 'Medium Brown', ar: 'بني متوسط' }, hex: '#6B4226' },
      { id: 'light-brown', name: { en: 'Light Brown', ar: 'بني فاتح' }, hex: '#A0522D' },
      { id: 'blonde', name: { en: 'Golden Blonde', ar: 'شقراء ذهبية' }, hex: '#D4A843' },
      { id: 'black', name: { en: 'Jet Black', ar: 'أسود' }, hex: '#1a1a1a' },
    ],
    lengths: [
      { id: '14', label: '14"', cm: 35, priceModifier: 0 },
      { id: '16', label: '16"', cm: 40, priceModifier: 500 },
      { id: '18', label: '18"', cm: 45, priceModifier: 1000 },
      { id: '20', label: '20"', cm: 50, priceModifier: 1500 },
    ],
    inStock: true,
    stockCount: 15,
    badge: 'bestseller',
    rating: 4.9,
    reviewCount: 124,
    features: [
      { en: '100% Indian Remy Human Hair', ar: 'شعر بشري هندي ريمي 100%' },
      { en: 'Heat stylable up to 180°C', ar: 'قابلة للتصفيف حتى 180 درجة' },
      { en: 'Seamless, undetectable attachment', ar: 'تركيب سلس غير مكتشف' },
      { en: 'Lasts 6-8 months with care', ar: 'تدوم 6-8 أشهر مع العناية' },
    ],
    sku: 'TI-IND-60G',
  },
  {
    id: 'russian-hair-100g',
    slug: 'russian-tape-in-hair-extensions-100g',
    name: { en: 'Russian Tape-In Extensions 100g', ar: 'وصلات لاصقة - شعر روسي 100g' },
    shortDescription: { en: 'Ultra-fine Russian hair extensions for the most natural, invisible blend', ar: 'وصلات شعر روسي فائقة النعومة للمزج الأكثر طبيعية وخفاءً' },
    description: { en: 'The ultimate in luxury hair extensions. Our Russian tape-in extensions feature the finest, softest hair in the world. Ultra-thin wefts that are completely invisible when applied.', ar: 'القمة في وصلات الشعر الفاخرة. وصلاتنا الروسية اللاصقة تتميز بأفضل وأناعم شعر في العالم.' },
    category: 'hair-extensions',
    extensionType: 'tape-in',
    price: 19000,
    images: ['/images/products/russian-100g-1.jpg'],
    badge: 'limited',
    rating: 5.0,
    reviewCount: 67,
    inStock: true,
    stockCount: 5,
    features: [
      { en: 'Ultra-fine Russian Remy hair', ar: 'شعر روسي ريمي فائق النعومة' },
      { en: 'Completely invisible application', ar: 'تركيب غير مرئي تماماً' },
      { en: 'Lasts 8-12 months', ar: 'تدوم 8-12 شهراً' },
    ],
    sku: 'TI-RUS-100G',
  },
  {
    id: 'lace-front-wig',
    slug: 'luxury-lace-front-wig',
    name: { en: 'Luxury Lace Front Wig', ar: 'باروكة لاصقة أمامية فاخرة' },
    shortDescription: { en: 'Hand-tied lace front wig, 100% human hair, invisible hairline', ar: 'باروكة لاصقة أمامية مربوطة يدوياً، شعر بشري 100%، خط شعر غير مرئي' },
    description: { en: 'Our luxury lace front wigs feature a hand-tied, transparent lace front for a completely natural-looking hairline. Made from 100% human hair that can be styled, colored, and treated just like your own hair.', ar: 'باروكاتنا اللاصقة الأمامية الفاخرة تتميز بدانتيل شفاف مربوط يدوياً لخط شعر طبيعي تماماً.' },
    category: 'wigs',
    price: 13000,
    images: ['/images/products/wig-lace-front-1.jpg'],
    badge: 'new',
    rating: 4.8,
    reviewCount: 34,
    inStock: true,
    features: [
      { en: 'Hand-tied transparent lace', ar: 'دانتيل شفاف مربوط يدوياً' },
      { en: 'Adjustable wig cap', ar: 'غطاء باروكة قابل للتعديل' },
      { en: 'Heat stylable', ar: 'قابلة للتصفيف بالحرارة' },
    ],
    sku: 'WIG-LF-001',
  },
  {
    id: 'hair-care-kit',
    slug: 'extension-care-maintenance-kit',
    name: { en: 'Extension Care & Maintenance Kit', ar: 'طقم عناية وصيانة الوصلات' },
    shortDescription: { en: 'Complete kit for keeping your extensions looking flawless', ar: 'طقم كامل للحفاظ على مظهر وصلاتك مثالياً' },
    description: { en: 'Everything you need to maintain your hair extensions between salon visits. Includes sulfate-free shampoo, conditioning mask, detangling brush, and care guide.', ar: 'كل ما تحتاجينه للحفاظ على وصلات شعرك بين زيارات الصالون.' },
    category: 'hair-care',
    price: 1200,
    originalPrice: 1500,
    images: ['/images/products/care-kit-1.jpg'],
    badge: 'sale',
    rating: 4.7,
    reviewCount: 89,
    inStock: true,
    features: [
      { en: 'Sulfate-free shampoo (500ml)', ar: 'شامبو خالٍ من الكبريتات (500مل)' },
      { en: 'Deep conditioning mask (300ml)', ar: 'ماسك مرطب عميق (300مل)' },
      { en: 'Professional detangling brush', ar: 'فرشاة احترافية لفك التشابك' },
    ],
    sku: 'KIT-CARE-001',
  },
];

export const QUIZ_RESULTS = {
  'tape-in': {
    en: {
      title: 'Tape-In Extensions',
      desc: 'Perfect for your hair type! Seamless, natural, and long-lasting. Our invisible double-face tape-in extensions blend beautifully with your natural hair for up to 8 months.',
      price: 'EGP 10,000 – 30,000',
    },
    ar: {
      title: 'وصلات لاصقة',
      desc: 'مثالية لنوع شعرك! سلسة وطبيعية وطويلة الأمد. وصلاتنا اللاصقة غير المرئية تتمازج بجمال مع شعرك الطبيعي حتى 8 أشهر.',
      price: '10,000 – 30,000 جنيه',
    },
  },
  'keratin': {
    en: {
      title: 'Keratin Bond Extensions',
      desc: 'Ideal for your thick hair! Keratin bonds provide the strongest hold and the most natural movement. Perfect for active lifestyles.',
      price: 'EGP 13,000+',
    },
    ar: {
      title: 'وصلات كيراتين',
      desc: 'مثالية لشعرك الكثيف! توفر وصلات الكيراتين أقوى ثبات وأكثر حركة طبيعية. مثالية لأسلوب الحياة النشط.',
      price: '13,000+ جنيه',
    },
  },
  'volume': {
    en: {
      title: 'Indian Premium Extensions',
      desc: 'Maximum volume with premium Indian hair — 100g at 60cm for stunning, full results. Achieve that celebrity hair you\'ve always dreamed of.',
      price: 'EGP 11,000+',
    },
    ar: {
      title: 'وصلات هندية ممتازة',
      desc: 'أقصى حجم مع شعر هندي ممتاز — 100 جرام بطول 60 سم لنتائج رائعة وكثيفة. احصلي على شعر المشاهير الذي طالما حلمتِ به.',
      price: '11,000+ جنيه',
    },
  },
};
